﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using InfirmerieBO; // Référence la couche BO
using InfirmerieDAL; // Référence la couche DAL

namespace InfirmerieBLL
{
    public class GestionVisites
    {
        private static GestionVisites uneGestionVisites; // Objet BLL

        // Accesseur en lecture
        public static GestionVisites GetGestionUtilisateurs()
        {
            if (uneGestionVisites == null)
            {
                uneGestionVisites = new GestionVisites();
            }
            return uneGestionVisites;
        }

        // Définit la chaîne de connexion grâce à la méthode SetchaineConnexion de la DAL
        public static void SetchaineConnexion(ConnectionStringSettings chset)
        {
            string chaine = chset.ConnectionString;
            ConnexionBD.GetConnexionBD().SetChaineConnexion(chaine);
        }

        // Méthode qui renvoie un objet Visite en faisant appel à la méthode GetVisite() de la DAL
        public static int VerifEleve(string libelle)
        {
            // Eleve unEleve = new Eleve();

            return 1;
                //MedicamentDAO.GetMedicament(unMedicament);
        }

        // Méthode qui créer un nouvel élève à partir de ses attributs et qui le renvoi en l'ajoutant à la BD avec la méthode AjoutEleve de la DAL
        public static int CreerVisite(string nom, string prenom, int age, DateTime date, DateTime heureArrivee, DateTime heureDepart, string motif, string commentaire, string pouls, string prescription, int quantite, bool status, bool parentPrevenu)
        {
            // Visite newVisite;
            // newVisite = new Visite(nom, prenom, age, date, heureArrivee, heureDepart, motif, commentaire, pouls, prescription, quantite, status, parentPrevenu);
            return 1; //VisiteDAO.AjoutEleve(el);
        }

        // méthode qui renvoi le nombre total de visite par période en faisant appel à la méthode NbTotalVisite() de la DAL
        public static int NbTotalVisite(string dateDebut, string dateFin)
        {
            return VisiteDAO.NbTotalVisite(dateDebut, dateFin);
        }
    }
}
