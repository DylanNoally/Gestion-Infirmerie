﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using InfirmerieBO; // Référence la couche BO
using InfirmerieDAL; // Référence la couche DAL

namespace InfirmerieBLL
{
    public class GestionVisites
    {
        private static GestionVisites uneGestionVisites; // Objet BLL

        // Accesseur en lecture
        public static GestionVisites GetGestionUtilisateurs()
        {
            if (uneGestionVisites == null)
            {
                uneGestionVisites = new GestionVisites();
            }
            return uneGestionVisites;
        }

        // Définit la chaîne de connexion grâce à la méthode SetchaineConnexion de la DAL
        public static void SetchaineConnexion(ConnectionStringSettings chset)
        {
            string chaine = chset.ConnectionString;
            ConnexionBD.GetConnexionBD().SetChaineConnexion(chaine);
        }

        // Méthode qui renvoie un objet Visite en faisant appel à la méthode GetVisite() de la DAL
        public static int VerifEleve(string libelle)
        {
            // Eleve unEleve = new Eleve();

            return 1;
                //MedicamentDAO.GetMedicament(unMedicament);
        }

        // Méthode qui créer un nouvel élève à partir de ses attributs et qui le renvoi en l'ajoutant à la BD avec la méthode AjoutEleve de la DAL
        public static int CreerVisite(DateTime heureArrivee, DateTime heureDepart, string motif, string commentaire, string pouls, int quantite, string status, bool parentPrevenu, int idEleve)
        {
            Visite newVisite;
            newVisite = new Visite(heureArrivee, heureDepart, motif, commentaire, pouls, quantite, status, parentPrevenu, idEleve);

            return VisiteDAO.AjoutVisite(newVisite);
        }

        public static int GetNbreVisites(DateTime Deb, DateTime Fin)
        {
            return VisiteDAO.NbreVisites(Deb, Fin);
        }

        public static double GetSommeTemps(DateTime Deb, DateTime Fin)
        {
            return VisiteDAO.TempsVisites(Deb, Fin);
        }

        public static int GetNbreMedics(DateTime Deb, DateTime Fin)
        {
            return VisiteDAO.NbreMedics(Deb, Fin);
        }

        public static List<Visite> GetVisite(int idEleve)
        {
            return VisiteDAO.GetVisite(idEleve);
        }

        public static int LierMedicVisite(int idMedic, int idVisite)
        {
            return VisiteDAO.LierMedVis(idMedic, idVisite);
        }

        public static int GetIdVisite(Visite uneVisite)
        {
            return VisiteDAO.GetIdVisite(uneVisite);
        }

        public static Visite GetUneVisite(int idVisite)
        {
            return VisiteDAO.GetLaVisite(idVisite);
        }

        public static int DeleteUneVisite(int idVisite)
        {
            return VisiteDAO.DeleteVisite(idVisite);
        }

        public static List<int> GetListeIdMedicamentsLies(int idVisite)
        {
            return VisiteDAO.listeIdMedicamentsLies(idVisite);
        }

        public static int DeleteAllMedVis(int idVisite)
        {
            return VisiteDAO.DeleteAllMedVis(idVisite);
        }

        public static int UpdateVisite(Visite uneVisite)
        {
            return VisiteDAO.UpdateVisite(uneVisite);
        }

        public static List<Visite> SearchVisites(DateTime date, int idEleve)
        {
            return VisiteDAO.SearchVisites(date, idEleve);
        }

        // méthode qui renvoi le nombre total de visite par période en faisant appel à la méthode NbTotalVisite() de la DAL
        public static int NbTotalVisite(DateTime dateDebut, DateTime dateFin)
        {
            return VisiteDAO.NbTotalVisite(dateDebut, dateFin);
        }
    }
}
