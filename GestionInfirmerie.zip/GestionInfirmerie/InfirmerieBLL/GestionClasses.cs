﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using InfirmerieBO; // Référence la couche BO
using InfirmerieDAL; // Référence la couche DAL
using System.Data;

namespace InfirmerieBLL
{
    public class GestionClasses
    {
        private static GestionClasses uneGestionClasses; // objet BLL

        // Accesseur en lecture
        public static GestionClasses GetGestionClasses()
        {
            if (uneGestionClasses == null)
            {
                uneGestionClasses = new GestionClasses();
            }
            return uneGestionClasses;
        }

        // Définit la chaîne de connexion grâce à la méthode SetchaineConnexion de la DAL
        public static void SetchaineConnexion(ConnectionStringSettings chset)
        {
            string chaine = chset.ConnectionString;
            ConnexionBD.GetConnexionBD().SetChaineConnexion(chaine);
        }

        public DataTable RecupererInfosClasses()
        {
            DataTable lesClasses = new DataTable();
            ClasseDAO infosClasse = new ClasseDAO();
            lesClasses = infosClasse.RecupererClasses();
            return lesClasses;
        }

        public static int VerifClasse(int id)
        {
            Classe uneClasse = new Classe(id);

            return ClasseDAO.GetClasse(uneClasse);
        }

        public static Classe ExtractInfosClasse(int id)
        {
            return ClasseDAO.GetClasseInfos(id);
        }

        // Méthode qui renvoit un objet Medicament en faisant appel à la méthode SuppressionMedicament() de la DAL
        public static int SuppressionClasse(int idClasse)
        {

            Classe laClasse = new Classe(idClasse);

            return ClasseDAO.SupprimerClasse(laClasse);
        }

        // Méthode qui créer une classe avec nom et emploi du temps
        public static int CreerUneClasseAvecEDT(string nom, string emploiDuTemps, int idNiveau)
        {
            Classe classe;
            classe = new Classe(nom, emploiDuTemps, idNiveau);
            return ClasseDAO.AjoutClasseAvecEDT(classe);
        }

        //public static void CreerEDT{
        //    DataTable tblcsv = new DataTable();
        //    string ReadCSV = File.ReadAllText(CSVFilePath);
        //    foreach (string csvRow in ReadCSV.Split('\n'))
        //    {
        //        if (!string.IsNullOrEmpty(csvRow))
        //        {
        //            tblcsv.Rows.Add();
        //            int count = 0;
        //            foreach (string FileRec in csvRow.Split(';'))
        //            {
        //                if ((tblcsv.Rows.Count - 1) == 0)
        //                {
        //                    tblcsv.Columns.Add(FileRec);
        //                }
        //                else
        //                {
        //                    tblcsv.Rows[tblcsv.Rows.Count - 1][count] = FileRec;
        //                }
        //                count++;
        //            }
        //        }
        //    }

        //    return tblcsv;

        //}

        // Méthode qui créer une classe avec nom mais sans l'emploi du temps
        public static int CreerUneClasseSansEDT(string nom, int idNiveau)
        {
            Classe classe;
            classe = new Classe(nom, idNiveau);
            return ClasseDAO.AjoutClasseSansEDT(classe);
        }

        public static List<Niveau> GetListeDesNiveaux()
        {
            return ClasseDAO.GetLesNiveaux();
        }

        public static List<Classe> GetListeDesClasses()
        {
            return ClasseDAO.GetLesClasses();
        }
    }
}
