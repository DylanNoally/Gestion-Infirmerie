﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using InfirmerieDAL; // Référence la couche DAL
using InfirmerieBO;  // Référence la couche BO
using System.Data;
using System.Text.RegularExpressions;
using System.Data.OleDb;
using System.IO;

namespace InfirmerieBLL
{
    public class GestionInfirmerie
    {
        private static GestionInfirmerie uneGestionInfirmerie; // Objet BLL

        // Accesseur en lecture
        public static GestionInfirmerie GetGestionInfirmerie()
        {
            if (uneGestionInfirmerie == null)
            {
                uneGestionInfirmerie = new GestionInfirmerie();
            }
            return uneGestionInfirmerie;
        }

        // Définit la chaine de connexion grâce à la méthode SetChaineConnexion de la DAL
        public static void SetChaineConnexion(ConnectionStringSettings chset)
        {
            string chaine = chset.ConnectionString;
            ConnexionBD.GetConnexionBD().SetChaineConnexion(chaine);
        }

        public List<string> recupererInfosClasses()
        {
            List<string> lesClasses = new List<string>();
            InfirmerieDAO infosClasse = new InfirmerieDAO();
            lesClasses = infosClasse.recupererClasses();
            return lesClasses;
        }

        public List<string> recupererInfosEleves(string libelle)
        {
            List<string> lesEleves = new List<string>();
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesEleves = infosEleve.recupererEleves(libelle);
            return lesEleves;
        }

        public Eleve recupererDetailsEleves(string nom, string prenom)
        {
            Eleve lesDetails;
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesDetails = infosEleve.recupererInfosEleves(nom, prenom);
            return lesDetails;
        }

        public List<string> recupererPrenomsEleves(string libelle)
        {
            List<string> lesEleves = new List<string>();
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesEleves = infosEleve.recupererPrenomsEleves(libelle);
            return lesEleves;
        }

        //public List<string> recupererInfosClasses()
        //{
        //    //DataTable lesClasses = new DataTable();
        //    //InfirmerieDAO infosClasse = new InfirmerieDAO();
        //    //lesClasses = infosClasse.recupererClasses();
        //    //return lesClasses;
        //}

        //public DataTable recupererInfosEleves(int idClasse)
        //{
        //    DataTable lesEleves = new DataTable();
        //    InfirmerieDAO infosEleve = new InfirmerieDAO();
        //    lesEleves = infosEleve.recupererEleves(idClasse);
        //    return lesEleves;
        //}

        //public Eleve recupererDetailsEleves(string nom, string prenom)
        //{
        //    Eleve lesDetails;
        //    InfirmerieDAO infosEleve = new InfirmerieDAO();
        //    lesDetails = infosEleve.recupererInfosEleves(nom, prenom);
        //    return lesDetails;
        //}

        //public DataTable recupererPrenomsEleves(string libelle)
        //{
        //    DataTable lesEleves = new DataTable();
        //    InfirmerieDAO infosEleve = new InfirmerieDAO();
        //    lesEleves = infosEleve.recupererPrenomsEleves(libelle);
        //    return lesEleves;
        //}

        // Méthode qui créer un nouvel élève à partir de ses attributs et qui le renvoi en l'ajoutant à la BD avec la méthode AjoutEleve de la DAL
        public static int CreerEleve(string nom, string prenom, DateTime naissance, string sante, string telEleve, string telParent, bool tierstemps, int classe)
        {
            Eleve nouvelEleve;
            nouvelEleve = new Eleve(nom, prenom, naissance, sante, telEleve, telParent, tierstemps, classe);
            return InfirmerieDAO.AjoutEleve(nouvelEleve);
        }

        public static int ModifierEleve(int id, string nom, string prenom, DateTime naissance, string sante, string telEleve, string telParent, bool archive, bool tierstemps, bool visite)
        {
            Eleve el;
            el = new Eleve(id, nom, prenom, naissance, sante, telEleve, telParent, archive, tierstemps, visite);
            return InfirmerieDAO.UpdateEleve(el);
        }

        public bool supprimerEleve(int id, string nom, string prenom, DateTime naissance, string sante, string telEleve, string telParent, bool archive, bool tierstemps, bool visite, int classe)
        {
            Eleve unEleve;
            unEleve = new Eleve(id, nom, prenom, naissance, sante, telEleve, telParent, archive, tierstemps, visite, classe);
            return InfirmerieDAO.supprimerEleve(unEleve);
        }

        //// Méthode qui renvoie un objet Medicament en faisant appel à la méthode GetMedicaments() de la DAL
        //public static int VerifEleve(int id)
        //{
        //    Eleve unEleve = new Eleve(id);

        //    return InfirmerieDAO.recupererIdEleve(unEleve);
        //}

        //// Méthode qui renvoit un objet Medicament en faisant appel à la méthode GetMedicaments() de la DAL
        //public static Eleve ExtractInfosEleve(int id)
        //{
        //    Eleve unEleve = new Eleve(id);

        //    return InfirmerieDAO.GetEleveInfos(unEleve);
        //}

        public static float NombreMoyenMedicamentsParVisite()
        {
            return InfirmerieDAO.NbMoyenMedicamentsParVisite();
        }

        // Méthode qui affiche le nombre total d'élève avec la méthode nbEleve de la DAL
        public static int afficheNbEleve()
        {
            return InfirmerieDAO.nbEleve();
        }

        // Méthode qui affiche le nombre de visite par période, sur le nombre total d'élève
        public static double afficheNbVisiteParPeriodeParEleve(int nbVisite)
        {
            int nbEleve;
            float moyenneVisiteParEleve;

            nbEleve = afficheNbEleve();

            moyenneVisiteParEleve = (float)nbVisite / (float)nbEleve;

            // La méthode Round() permet d'arrondir un nombre à virgule
            // Fonctionne que sur des variables de type "double"
            // Notre méthode est de type "double" donc les "return" peut contenir la méthode "Round" de la classe "Math"
            return Math.Round(moyenneVisiteParEleve, 2);
        }

        // Méthode qui affiche le nombre de visite par période avec les date de début et de fin passées en parametre
        // A l'aide de la méthode nbVisiteParPeriode de la DAL
        public static int afficheNbVisiteParPeriode(string dateDebut, string dateFin)
        {
            return InfirmerieDAO.nbVisiteParPeriode(dateDebut, dateFin);
        }

        public class CSVconf
        {
            public CSVconf()
            {

            }

            public DataTable getDataTablefromCSV(string CSVFilePath)
            {
                DataTable tblcsv = new DataTable();
                string ReadCSV = File.ReadAllText(CSVFilePath);
                foreach (string csvRow in ReadCSV.Split('\n'))
                {
                    if (!string.IsNullOrEmpty(csvRow))
                    {
                        tblcsv.Rows.Add();
                        int count = 0;
                        foreach (string FileRec in csvRow.Split(';'))
                        {
                            if ((tblcsv.Rows.Count - 1) == 0)
                            {
                                tblcsv.Columns.Add(FileRec);
                            }
                            else
                            {
                                tblcsv.Rows[tblcsv.Rows.Count - 1][count] = FileRec;
                            }
                            count++;
                        }
                    }
                }

                return tblcsv;
            }
            
            //public List<string> importCSVdatas(DataTable tblcsv)
            //{
            //    List<string> statImport = new List<string>();


            //    DataTableReader data = new DataTableReader(tblcsv);
            //    CSVintoDatabase importDatas = new CSVintoDatabase();

            //    statImport = importDatas.dataImport(data);

            //    return statImport;
            //}
        }
    }
}
