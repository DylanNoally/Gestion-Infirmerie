﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using InfirmerieDAL; // Référence la couche DAL
using InfirmerieBO;  // Référence la couche BO

namespace InfirmerieBLL
{
    public class GestionInfirmerie
    {
        private static GestionInfirmerie uneGestionInfirmerie; // Objet BLL

        // Accesseur en lecture
        public static GestionInfirmerie GetGestionInfirmerie()
        {
            if (uneGestionInfirmerie == null)
            {
                uneGestionInfirmerie = new GestionInfirmerie();
            }
            return uneGestionInfirmerie;
        }

        // Définit la chaine de connexion grâce à la méthode SetChaineConnexion de la DAL
        public static void SetChaineConnexion(ConnectionStringSettings chset)
        {
            string chaine = chset.ConnectionString;
            ConnexionBD.GetConnexionBD().SetChaineConnexion(chaine);
        }

        public List<string> recupererInfosClasses()
        {
            List<string> lesClasses = new List<string>();
            InfirmerieDAO infosClasse = new InfirmerieDAO();
            lesClasses = infosClasse.recupererClasses();
            return lesClasses;
        }

        public List<string> recupererInfosEleves(string libelle)
        {
            List<string> lesEleves = new List<string>();
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesEleves = infosEleve.recupererEleves(libelle);
            return lesEleves;
        }

        public List<Eleve> recupererLesEleves(string libelle)
        {
            List<Eleve> lesEleves = new List<Eleve>();
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesEleves = infosEleve.recupererLesEleves(libelle);
            return lesEleves;
        }

        public Eleve recupererDetailsEleves(string nom, string prenom)
        {
            Eleve lesDetails;
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesDetails = infosEleve.recupererInfosEleves(nom, prenom);
            return lesDetails;
        }

        public Eleve recupererDetailsEleve(int idEleve)
        {
            Eleve lesDetails;
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesDetails = infosEleve.recupererInfosEleve(idEleve);
            return lesDetails;
        }

        public List<string> recupererPrenomsEleves(string libelle)
        {
            List<string> lesEleves = new List<string>();
            InfirmerieDAO infosEleve = new InfirmerieDAO();
            lesEleves = infosEleve.recupererPrenomsEleves(libelle);
            return lesEleves;
        }

        // Méthode qui créer un nouvel élève à partir de ses attributs et qui le renvoi en l'ajoutant à la BD avec la méthode AjoutEleve de la DAL
        public static int CreerEleve(string nom, string prenom, DateTime naissance, string sante, string telEleve, string telParent, bool archive, bool tierstemps, bool visite, int classe)
        {
            Eleve el;
            el = new Eleve(nom, prenom, naissance, sante, telEleve, telParent, archive, tierstemps, visite, classe);
            return InfirmerieDAO.AjoutEleve(el, classe);
        }

        public static int ModifierEleve(int id, string nom, string prenom, DateTime naissance, string sante, string telEleve, string telParent, bool archive, bool tierstemps, bool visite)
        {
           Eleve el;
           el = new Eleve(id, nom, prenom, naissance, sante, telEleve, telParent, archive, tierstemps, visite);
           return InfirmerieDAO.UpdateEleve(el);
        }

        public static bool supprimerEleve(int id)
        {
            return InfirmerieDAO.supprimerEleve(id);
        }

        public static float NombreMoyenMedicamentsParVisite(int deb, int fin)
        {
            return InfirmerieDAO.NbMoyenMedicamentsParVisite(deb, fin);
        }

        public static float NombreMoyenMedicamentsParVisiteTotal()
        {
            return InfirmerieDAO.NbMoyenMedicamentsParVisiteTotal();
        }

        // Méthode qui affiche le nombre total d'élève avec la méthode nbEleve de la DAL
        public static int afficheNbEleve()
        {
            return InfirmerieDAO.nbEleve();
        }

        // Méthode qui affiche le nombre de visite par période, sur le nombre total d'élève
        public static double afficheNbVisiteParPeriodeParEleve(int nbVisite)
        {
            int nbEleve;
            float moyenneVisiteParEleve;

            nbEleve = afficheNbEleve();

            moyenneVisiteParEleve = (float)nbVisite / (float)nbEleve;

            // La méthode Round() permet d'arrondir un nombre à virgule
            // Fonctionne que sur des variables de type "double"
            // Notre méthode est de type "double" donc les "return" peut contenir la méthode "Round" de la classe "Math"
            return Math.Round(moyenneVisiteParEleve, 2);
        }

        // Méthode qui affiche le nombre de visite par période avec les date de début et de fin passées en parametre
        // A l'aide de la méthode nbVisiteParPeriode de la DAL
        public static int afficheNbVisiteParPeriode(string dateDebut, string dateFin)
        {
            return InfirmerieDAO.nbVisiteParPeriode(dateDebut, dateFin);
        }

        public static int SauvegardeBDD(string lien)
        {
            return InfirmerieDAO.saveBDD(lien);
        }
    }
}
