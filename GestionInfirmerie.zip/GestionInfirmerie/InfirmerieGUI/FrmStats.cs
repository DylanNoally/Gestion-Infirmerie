﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmStats : Form
    {
        public FrmStats()
        {
            InitializeComponent();
        }

        private void titreAccueil_Click(object sender, EventArgs e)
        {

        }

        private void FrmStats_Load(object sender, EventArgs e)
        {

        }

        private void btnGestionEleves_Click(object sender, EventArgs e)
        {
            // Variable qui récupère la valeur retourner de la méthode NombreMoyenMedicamentsParVisite
            float nbMedicaments = GestionInfirmerie.NombreMoyenMedicamentsParVisite();

            MessageBox.Show("Le nombre moyen de médicaments donnés par visite est de " + nbMedicaments);
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorPeriodeInfo.Clear();
            errorPeriode.Clear();

            // Controles de saisie
            if (dtpDateDebutVisites.Value.ToString() == dtpDateFinVisites.Value.ToString())
            {
                errorPeriodeInfo.SetError(dtpDateFinVisites, "Sélectionner deux périodes identiques n'est pas possible");
                errorPeriode.SetError(dtpDateDebutVisites, dtpDateDebutVisites.Value.ToString() + "-" + dtpDateFinVisites.Value.ToString());
            }
            else if (DateTime.Parse(dtpDateDebutVisites.Value.ToString()) > DateTime.Parse(dtpDateFinVisites.Value.ToString()))
            {
                errorPeriode.SetError(dtpDateDebutVisites, "La date de début ne peut être supérieur à la date de fin");
            }
            else
            {
                string dateDebut = dtpDateDebutVisites.Value.ToShortDateString();
                string dateFin = dtpDateFinVisites.Value.ToShortDateString();
                int nbVisite;

                double moyenneVisiteParPeriodeParEleve;

                nbVisite = GestionInfirmerie.afficheNbVisiteParPeriode(dateDebut, dateFin);

                moyenneVisiteParPeriodeParEleve = GestionInfirmerie.afficheNbVisiteParPeriodeParEleve(nbVisite);
                MessageBox.Show("Il y a une moyenne de " + moyenneVisiteParPeriodeParEleve + " visites par élève");
            }
        }

        private void dtpDateDebutVisites_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonNbTotalVisite_Click(object sender, EventArgs e)
        {
            string DateDebut;
            string DateFin;
            int nbVisitePeriode;

            DateDebut = dtpDateDebutVisites.Value.ToShortDateString();
            DateFin = dtpDateFinVisites.Value.ToShortDateString();

            nbVisitePeriode = GestionVisites.NbTotalVisite(DateDebut, DateFin);
            MessageBox.Show("Le nombre total de visite entre le " + DateDebut + " et le " + DateFin + " est de " + nbVisitePeriode);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
