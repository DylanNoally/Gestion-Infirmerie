﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmStats : Form
    {
        public FrmStats()
        {
            InitializeComponent();
        }
         
        private void titreAccueil_Click(object sender, EventArgs e)
        {

        }

        private void FrmStats_Load(object sender, EventArgs e)
        {

        }

        private void btnGestionEleves_Click(object sender, EventArgs e)
        {
            // Variable qui récupère la valeur retourner de la méthode NombreMoyenMedicamentsParVisite
            float nbMedicaments = GestionInfirmerie.NombreMoyenMedicamentsParVisiteTotal();

            MessageBox.Show("Le nombre moyen de médicaments donnés par visite est de " + nbMedicaments);
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            errorPeriodeInfo.Clear();
            errorPeriode.Clear();

            // Controles de saisie
            if (dtpDateDebutVisites.Value.ToString() == dtpDateFinVisites.Value.ToString())
            {
                errorPeriodeInfo.SetError(dtpDateFinVisites, "Sélectionner deux périodes identiques n'est pas possible");
                errorPeriode.SetError(dtpDateDebutVisites, dtpDateDebutVisites.Value.ToString() + "-" + dtpDateFinVisites.Value.ToString());
            }
            else if (DateTime.Parse(dtpDateDebutVisites.Value.ToString()) > DateTime.Parse(dtpDateFinVisites.Value.ToString()))
            {
                errorPeriode.SetError(dtpDateDebutVisites, "La date de début ne peut être supérieur à la date de fin");
            }
            else
            {
                string dateDebut = dtpDateDebutVisites.Value.ToShortDateString();
                string dateFin = dtpDateFinVisites.Value.ToShortDateString();
                int nbVisite;

                double moyenneVisiteParPeriodeParEleve;

                nbVisite = GestionInfirmerie.afficheNbVisiteParPeriode(dateDebut, dateFin);

                moyenneVisiteParPeriodeParEleve = GestionInfirmerie.afficheNbVisiteParPeriodeParEleve(nbVisite);
                MessageBox.Show("Il y a une moyenne de " + moyenneVisiteParPeriodeParEleve + " visites par élève");
            }
        }

        private void dtpDateDebutVisites_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void logoStVincent_Click(object sender, EventArgs e)
        {

        }

        private void titreAccueil_Click_1(object sender, EventArgs e)
        {

        }

        private void titreGestionInfirmerie_Click(object sender, EventArgs e)
        {

        }

        private void dtpDateFinVisites_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnElevesTotal_Click(object sender, EventArgs e)
        {
            int nbTotalEleve = GestionInfirmerie.afficheNbEleve();
            MessageBox.Show("Il y a " + nbTotalEleve + " élève(s) enregistré(s).");
        }

        private void btnRetour_Click_1(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void btnNbreVisitesMoy_Click(object sender, EventArgs e)
        {
            errorPeriodeInfo.Clear();
            errorPeriode.Clear();

            // Controles de saisie
            if (dtpDateDebutVisites.Value.ToString() == dtpDateFinVisites.Value.ToString())
            {
                errorPeriodeInfo.SetError(dtpDateFinVisites, "Sélectionner deux périodes identiques n'est pas possible");
                errorPeriode.SetError(dtpDateDebutVisites, dtpDateDebutVisites.Value.ToString() + "-" + dtpDateFinVisites.Value.ToString());
            }
            else if (DateTime.Parse(dtpDateDebutVisites.Value.ToString()) > DateTime.Parse(dtpDateFinVisites.Value.ToString()))
            {
                errorPeriode.SetError(dtpDateDebutVisites, "La date de début ne peut être supérieur à la date de fin");
            }
            else
            {
                string dateDebut = dtpDateDebutVisites.Value.ToShortDateString();
                string dateFin = dtpDateFinVisites.Value.ToShortDateString();
                int nbVisite;

                double moyenneVisiteParPeriodeParEleve;

                nbVisite = GestionInfirmerie.afficheNbVisiteParPeriode(dateDebut, dateFin);

                moyenneVisiteParPeriodeParEleve = GestionInfirmerie.afficheNbVisiteParPeriodeParEleve(nbVisite);
                MessageBox.Show("Il y a une moyenne de " + moyenneVisiteParPeriodeParEleve + " visites par élève");
            }
        }

        private void buttonNbTotalVisite_Click_1(object sender, EventArgs e)
        {
            string DateDebut;
            string DateFin;
            int nbVisitePeriode;

            DateDebut = dtpDateDebutVisites.Value.ToShortDateString();
            DateFin = dtpDateFinVisites.Value.ToShortDateString();

            nbVisitePeriode = GestionVisites.NbTotalVisite(DateDebut, DateFin);
            MessageBox.Show("Le nombre total de visite entre le " + DateDebut + " et le " + DateFin + " est de " + nbVisitePeriode);
        }

        private void btnNbTotalMedic_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Il y a " + GestionInfirmerie.NombreMoyenMedicamentsParVisite(dtpDateDebutVisites.Value.Year, dtpDateFinVisites.Value.Year) + " médicament(s), en moyenne, par visite sur cette période.");
        }

        private void btnTempsMoyenVisite_Click(object sender, EventArgs e)
        {
            DateTime dateDeb = dtpDateDebutVisites.Value;
            DateTime dateFin = dtpDateFinVisites.Value;

            int nbreVisites = GestionVisites.GetNbreVisites(dateDeb, dateFin);
            double sommeTemps = GestionVisites.GetSommeTemps(dateDeb, dateFin);

            double temps = (sommeTemps / nbreVisites);
            temps = Math.Floor(temps);

            MessageBox.Show("Une visite dure en moyenne "+temps+" minutes.");
        }
    }
}
