﻿namespace InfirmerieGUI
{
    partial class FrmModifierVisite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmModifierVisite));
            this.btnRetour = new System.Windows.Forms.Button();
            this.lblMotif = new System.Windows.Forms.Label();
            this.lblCommentaire = new System.Windows.Forms.Label();
            this.lblTimeEntree = new System.Windows.Forms.Label();
            this.lblTimeSortie = new System.Windows.Forms.Label();
            this.lblParents = new System.Windows.Forms.Label();
            this.lblPouls = new System.Windows.Forms.Label();
            this.lblQte = new System.Windows.Forms.Label();
            this.txtMotif = new System.Windows.Forms.TextBox();
            this.nupQte = new System.Windows.Forms.NumericUpDown();
            this.nupPouls = new System.Windows.Forms.NumericUpDown();
            this.cbParents = new System.Windows.Forms.CheckBox();
            this.commentSante = new System.Windows.Forms.RichTextBox();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            this.lblModifVisite = new System.Windows.Forms.Label();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnSuppress = new System.Windows.Forms.Button();
            this.dtpEntree = new System.Windows.Forms.DateTimePicker();
            this.dtpSortie = new System.Windows.Forms.DateTimePicker();
            this.rbLycee = new System.Windows.Forms.RadioButton();
            this.rbDomicile = new System.Windows.Forms.RadioButton();
            this.rbHopital = new System.Windows.Forms.RadioButton();
            this.lblStatut = new System.Windows.Forms.Label();
            this.clbMedicaments = new System.Windows.Forms.CheckedListBox();
            ((System.ComponentModel.ISupportInitialize)(this.nupQte)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPouls)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRetour
            // 
            this.btnRetour.Location = new System.Drawing.Point(522, 22);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(75, 23);
            this.btnRetour.TabIndex = 29;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = true;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // lblMotif
            // 
            this.lblMotif.AutoSize = true;
            this.lblMotif.Location = new System.Drawing.Point(42, 99);
            this.lblMotif.Name = "lblMotif";
            this.lblMotif.Size = new System.Drawing.Size(39, 13);
            this.lblMotif.TabIndex = 30;
            this.lblMotif.Text = "Motif  :";
            // 
            // lblCommentaire
            // 
            this.lblCommentaire.AutoSize = true;
            this.lblCommentaire.Location = new System.Drawing.Point(42, 137);
            this.lblCommentaire.Name = "lblCommentaire";
            this.lblCommentaire.Size = new System.Drawing.Size(74, 13);
            this.lblCommentaire.TabIndex = 31;
            this.lblCommentaire.Text = "Commentaire :";
            // 
            // lblTimeEntree
            // 
            this.lblTimeEntree.AutoSize = true;
            this.lblTimeEntree.Location = new System.Drawing.Point(42, 286);
            this.lblTimeEntree.Name = "lblTimeEntree";
            this.lblTimeEntree.Size = new System.Drawing.Size(75, 13);
            this.lblTimeEntree.TabIndex = 32;
            this.lblTimeEntree.Text = "Heure entrée :";
            // 
            // lblTimeSortie
            // 
            this.lblTimeSortie.AutoSize = true;
            this.lblTimeSortie.Location = new System.Drawing.Point(42, 323);
            this.lblTimeSortie.Name = "lblTimeSortie";
            this.lblTimeSortie.Size = new System.Drawing.Size(70, 13);
            this.lblTimeSortie.TabIndex = 33;
            this.lblTimeSortie.Text = "Heure sortie :";
            // 
            // lblParents
            // 
            this.lblParents.AutoSize = true;
            this.lblParents.Location = new System.Drawing.Point(346, 159);
            this.lblParents.Name = "lblParents";
            this.lblParents.Size = new System.Drawing.Size(96, 13);
            this.lblParents.TabIndex = 36;
            this.lblParents.Text = "Parents prévenus :";
            // 
            // lblPouls
            // 
            this.lblPouls.AutoSize = true;
            this.lblPouls.Location = new System.Drawing.Point(481, 160);
            this.lblPouls.Name = "lblPouls";
            this.lblPouls.Size = new System.Drawing.Size(39, 13);
            this.lblPouls.TabIndex = 37;
            this.lblPouls.Text = "Pouls :";
            // 
            // lblQte
            // 
            this.lblQte.AutoSize = true;
            this.lblQte.Location = new System.Drawing.Point(366, 324);
            this.lblQte.Name = "lblQte";
            this.lblQte.Size = new System.Drawing.Size(118, 13);
            this.lblQte.TabIndex = 38;
            this.lblQte.Text = "Quantité médicaments :";
            // 
            // txtMotif
            // 
            this.txtMotif.Location = new System.Drawing.Point(88, 99);
            this.txtMotif.Name = "txtMotif";
            this.txtMotif.Size = new System.Drawing.Size(198, 20);
            this.txtMotif.TabIndex = 39;
            // 
            // nupQte
            // 
            this.nupQte.Location = new System.Drawing.Point(490, 322);
            this.nupQte.Name = "nupQte";
            this.nupQte.Size = new System.Drawing.Size(57, 20);
            this.nupQte.TabIndex = 44;
            // 
            // nupPouls
            // 
            this.nupPouls.Location = new System.Drawing.Point(526, 158);
            this.nupPouls.Name = "nupPouls";
            this.nupPouls.Size = new System.Drawing.Size(57, 20);
            this.nupPouls.TabIndex = 45;
            // 
            // cbParents
            // 
            this.cbParents.AutoSize = true;
            this.cbParents.Location = new System.Drawing.Point(448, 159);
            this.cbParents.Name = "cbParents";
            this.cbParents.Size = new System.Drawing.Size(15, 14);
            this.cbParents.TabIndex = 48;
            this.cbParents.UseVisualStyleBackColor = true;
            // 
            // commentSante
            // 
            this.commentSante.Location = new System.Drawing.Point(45, 153);
            this.commentSante.Name = "commentSante";
            this.commentSante.Size = new System.Drawing.Size(241, 116);
            this.commentSante.TabIndex = 51;
            this.commentSante.Text = "";

            //
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(288, 12);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 53;
            this.logoStVincent.TabStop = false;
            // 
            // lblModifVisite
            // 
            this.lblModifVisite.AutoSize = true;
            this.lblModifVisite.Location = new System.Drawing.Point(261, 71);
            this.lblModifVisite.Name = "lblModifVisite";
            this.lblModifVisite.Size = new System.Drawing.Size(99, 13);
            this.lblModifVisite.TabIndex = 54;
            this.lblModifVisite.Text = "Modifier une Visite :";
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(197, 356);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(100, 34);
            this.btnModifier.TabIndex = 55;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnSuppress
            // 
            this.btnSuppress.Location = new System.Drawing.Point(334, 356);
            this.btnSuppress.Name = "btnSuppress";
            this.btnSuppress.Size = new System.Drawing.Size(100, 34);
            this.btnSuppress.TabIndex = 56;
            this.btnSuppress.Text = "Supprimer";
            this.btnSuppress.UseVisualStyleBackColor = true;
            this.btnSuppress.Click += new System.EventHandler(this.btnSuppress_Click);
            // 
            // dtpEntree
            // 
            this.dtpEntree.CustomFormat = "HH:mm";
            this.dtpEntree.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEntree.Location = new System.Drawing.Point(127, 286);
            this.dtpEntree.Name = "dtpEntree";
            this.dtpEntree.ShowUpDown = true;
            this.dtpEntree.Size = new System.Drawing.Size(159, 20);
            this.dtpEntree.TabIndex = 57;
            // 
            // dtpSortie
            // 
            this.dtpSortie.CustomFormat = "HH:mm";
            this.dtpSortie.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSortie.Location = new System.Drawing.Point(127, 317);
            this.dtpSortie.Name = "dtpSortie";
            this.dtpSortie.ShowUpDown = true;
            this.dtpSortie.Size = new System.Drawing.Size(159, 20);
            this.dtpSortie.TabIndex = 58;
            // 
            // rbLycee
            // 
            this.rbLycee.AutoSize = true;
            this.rbLycee.Location = new System.Drawing.Point(334, 124);
            this.rbLycee.Name = "rbLycee";
            this.rbLycee.Size = new System.Drawing.Size(65, 17);
            this.rbLycee.TabIndex = 61;
            this.rbLycee.TabStop = true;
            this.rbLycee.Text = "au lycée";
            this.rbLycee.UseVisualStyleBackColor = true;
            // 
            // rbDomicile
            // 
            this.rbDomicile.AutoSize = true;
            this.rbDomicile.Location = new System.Drawing.Point(412, 124);
            this.rbDomicile.Name = "rbDomicile";
            this.rbDomicile.Size = new System.Drawing.Size(92, 17);
            this.rbDomicile.TabIndex = 62;
            this.rbDomicile.TabStop = true;
            this.rbDomicile.Text = "à son domicile";
            this.rbDomicile.UseVisualStyleBackColor = true;
            // 
            // rbHopital
            // 
            this.rbHopital.AutoSize = true;
            this.rbHopital.Location = new System.Drawing.Point(516, 124);
            this.rbHopital.Name = "rbHopital";
            this.rbHopital.Size = new System.Drawing.Size(69, 17);
            this.rbHopital.TabIndex = 63;
            this.rbHopital.TabStop = true;
            this.rbHopital.Text = "à l\'hôpital";
            this.rbHopital.UseVisualStyleBackColor = true;
            // 
            // lblStatut
            // 
            this.lblStatut.AutoSize = true;
            this.lblStatut.Location = new System.Drawing.Point(334, 99);
            this.lblStatut.Name = "lblStatut";
            this.lblStatut.Size = new System.Drawing.Size(89, 13);
            this.lblStatut.TabIndex = 64;
            this.lblStatut.Text = "Statut de l\'élève :";
            // 
            // clbMedicaments
            // 
            this.clbMedicaments.FormattingEnabled = true;
            this.clbMedicaments.Location = new System.Drawing.Point(349, 188);
            this.clbMedicaments.Name = "clbMedicaments";
            this.clbMedicaments.Size = new System.Drawing.Size(234, 124);
            this.clbMedicaments.TabIndex = 65;
            // 
            // FrmModifierVisite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 402);
            this.Controls.Add(this.clbMedicaments);
            this.Controls.Add(this.lblStatut);
            this.Controls.Add(this.rbHopital);
            this.Controls.Add(this.rbDomicile);
            this.Controls.Add(this.rbLycee);
            this.Controls.Add(this.dtpSortie);
            this.Controls.Add(this.dtpEntree);
            this.Controls.Add(this.btnSuppress);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.lblModifVisite);
            this.Controls.Add(this.logoStVincent);
            this.Controls.Add(this.commentSante);
            this.Controls.Add(this.cbParents);
            this.Controls.Add(this.nupPouls);
            this.Controls.Add(this.nupQte);
            this.Controls.Add(this.txtMotif);
            this.Controls.Add(this.lblQte);
            this.Controls.Add(this.lblPouls);
            this.Controls.Add(this.lblParents);
            this.Controls.Add(this.lblTimeSortie);
            this.Controls.Add(this.lblTimeEntree);
            this.Controls.Add(this.lblCommentaire);
            this.Controls.Add(this.lblMotif);
            this.Controls.Add(this.btnRetour);
            this.Name = "FrmModifierVisite";
            this.Text = "FrmModifierVisite";
            ((System.ComponentModel.ISupportInitialize)(this.nupQte)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupPouls)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRetour;
        private System.Windows.Forms.Label lblMotif;
        private System.Windows.Forms.Label lblCommentaire;
        private System.Windows.Forms.Label lblTimeEntree;
        private System.Windows.Forms.Label lblTimeSortie;
        private System.Windows.Forms.Label lblParents;
        private System.Windows.Forms.Label lblPouls;
        private System.Windows.Forms.Label lblQte;
        private System.Windows.Forms.TextBox txtMotif;
        private System.Windows.Forms.NumericUpDown nupQte;
        private System.Windows.Forms.NumericUpDown nupPouls;
        private System.Windows.Forms.CheckBox cbParents;
        private System.Windows.Forms.RichTextBox commentSante;
        private System.Windows.Forms.PictureBox logoStVincent;
        private System.Windows.Forms.Label lblModifVisite;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnSuppress;
        private System.Windows.Forms.DateTimePicker dtpEntree;
        private System.Windows.Forms.DateTimePicker dtpSortie;
        private System.Windows.Forms.RadioButton rbLycee;
        private System.Windows.Forms.RadioButton rbDomicile;
        private System.Windows.Forms.RadioButton rbHopital;
        private System.Windows.Forms.Label lblStatut;
        private System.Windows.Forms.CheckedListBox clbMedicaments;

    }
}