﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using System.Data.OleDb;
using System.IO;
using System.Configuration;


namespace InfirmerieGUI
{
    public partial class FrmAjoutClasse : Form
    {
        private DataTable CSVdatas;

        public FrmAjoutClasse()
        {
            InitializeComponent();
            // Récupération de la chaine de connexion à la BD à l'ouverture du formulaire
            GestionInfirmerie.SetChaineConnexion(ConfigurationManager.ConnectionStrings["Infirmerie"]);
        }

        private void FrmAjoutEleve_Load(object sender, EventArgs e)
        {

        }


        //private void btnEnregistrer_Click(object sender, EventArgs e)
        //{

        //    // Effacement de la valeur saisie après enregistrement
        //    string libelle = textNomEleve.Text;
        //    string emploiDuTemps = "";

        //    GestionClasses uneClasse = new CreerUneClasseSansEDT(libelle);

        //    FrmAccueil Accueil = new FrmAccueil();
        //    Accueil.Show();
        //    this.Hide();
        //}

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmGestionClasses gestionClasse = new FrmGestionClasses();
            gestionClasse.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //OpenFileDialog openFileDialogCSV = new OpenFileDialog();
            //openFileDialogCSV.Filter = "Fichiers Excel | *.csv";
            //openFileDialogCSV.Title = "Sélectionnez un fichier CSV";
            //openFileDialogCSV.DefaultExt = "csv";

            //if (openFileDialogCSV.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            //{
            //    string filepath = openFileDialogCSV.FileName;
            //    string ext = Path.GetExtension(filepath);

            //    if (ext != ".csv")
            //    {
            //        MessageBox.Show("Mauvaise extension, sélectionnez un fichier CSV.", "Erreur : mauvaise extension", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    }
            //    else
            //    {
            //        CSVconf CSVtoImport = new CSVconf();
            //        DataTable CSVTable = new DataTable();
            //        CSVTable = CSVtoImport.getDataTablefromCSV(filepath);
            //        this.CSVdatas = CSVTable;
            //        this.CancelButton.Visible = true;
            //        this.ConfirmButton.Visible = true;
            //        dataGridViewExcel.DataSource = CSVTable;
            //        dataGridViewExcel.Visible = true;
            //    }
            //}
        }

        private void checkTT_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {

        }
    }
}
