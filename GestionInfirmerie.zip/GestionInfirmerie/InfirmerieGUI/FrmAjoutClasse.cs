﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBO;
using InfirmerieBLL;

namespace InfirmerieGUI
{
    public partial class FrmAjoutClasse : Form
    {
        private PictureBox logoStVincent;
        private Button btnRetour;
        private Label labelNaissanceEleve;
        private Label labelPrenomEleve;
        private Label labelCom;
        private Label labelClasseEleve;
        private Label labelNomEleve;
        private TextBox textNomClasse;
        private Button btnEnregistrer;
        private Label label1;
        private Label lblNiveau;
        private ComboBox cbNiveau;

        private int idNiveau;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmAjoutClasse()
        {
            InitializeComponent();

            List<Niveau> lesNiveaux = new List<Niveau>();
            lesNiveaux = GestionClasses.GetListeDesNiveaux();

            foreach (Niveau unNiveau in lesNiveaux)
            {
                cbNiveau.Items.Add(new ComboBoxItem(unNiveau.Id, unNiveau.Libelle));
            }

            btnEnregistrer.Enabled = false;
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAjoutClasse));
            this.btnRetour = new System.Windows.Forms.Button();
            this.labelNaissanceEleve = new System.Windows.Forms.Label();
            this.labelPrenomEleve = new System.Windows.Forms.Label();
            this.labelCom = new System.Windows.Forms.Label();
            this.labelClasseEleve = new System.Windows.Forms.Label();
            this.labelNomEleve = new System.Windows.Forms.Label();
            this.textNomClasse = new System.Windows.Forms.TextBox();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.cbNiveau = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRetour
            // 
            this.btnRetour.Location = new System.Drawing.Point(355, 12);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(75, 23);
            this.btnRetour.TabIndex = 32;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = true;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click_1);
            // 
            // labelNaissanceEleve
            // 
            this.labelNaissanceEleve.AutoSize = true;
            this.labelNaissanceEleve.Location = new System.Drawing.Point(345, 168);
            this.labelNaissanceEleve.Name = "labelNaissanceEleve";
            this.labelNaissanceEleve.Size = new System.Drawing.Size(0, 13);
            this.labelNaissanceEleve.TabIndex = 31;
            // 
            // labelPrenomEleve
            // 
            this.labelPrenomEleve.AutoSize = true;
            this.labelPrenomEleve.Location = new System.Drawing.Point(342, 114);
            this.labelPrenomEleve.Name = "labelPrenomEleve";
            this.labelPrenomEleve.Size = new System.Drawing.Size(0, 13);
            this.labelPrenomEleve.TabIndex = 30;
            // 
            // labelCom
            // 
            this.labelCom.AutoSize = true;
            this.labelCom.Location = new System.Drawing.Point(-38, 245);
            this.labelCom.Name = "labelCom";
            this.labelCom.Size = new System.Drawing.Size(0, 13);
            this.labelCom.TabIndex = 29;
            // 
            // labelClasseEleve
            // 
            this.labelClasseEleve.AutoSize = true;
            this.labelClasseEleve.Location = new System.Drawing.Point(-47, 156);
            this.labelClasseEleve.Name = "labelClasseEleve";
            this.labelClasseEleve.Size = new System.Drawing.Size(0, 13);
            this.labelClasseEleve.TabIndex = 28;
            // 
            // labelNomEleve
            // 
            this.labelNomEleve.AutoSize = true;
            this.labelNomEleve.Location = new System.Drawing.Point(74, 124);
            this.labelNomEleve.Name = "labelNomEleve";
            this.labelNomEleve.Size = new System.Drawing.Size(94, 13);
            this.labelNomEleve.TabIndex = 27;
            this.labelNomEleve.Text = "Nom de la classe :";
            // 
            // textNomClasse
            // 
            this.textNomClasse.Location = new System.Drawing.Point(174, 121);
            this.textNomClasse.Name = "textNomClasse";
            this.textNomClasse.Size = new System.Drawing.Size(155, 20);
            this.textNomClasse.TabIndex = 26;
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.Location = new System.Drawing.Point(143, 219);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(186, 42);
            this.btnEnregistrer.TabIndex = 25;
            this.btnEnregistrer.Text = "Enregistrer la classe";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label1.Location = new System.Drawing.Point(132, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 20);
            this.label1.TabIndex = 24;
            this.label1.Text = "Ajouter une classe :";
            // 
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(187, 14);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 33;
            this.logoStVincent.TabStop = false;
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Location = new System.Drawing.Point(121, 168);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(47, 13);
            this.lblNiveau.TabIndex = 35;
            this.lblNiveau.Text = "Niveau :";
            // 
            // cbNiveau
            // 
            this.cbNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbNiveau.FormattingEnabled = true;
            this.cbNiveau.Location = new System.Drawing.Point(174, 165);
            this.cbNiveau.Name = "cbNiveau";
            this.cbNiveau.Size = new System.Drawing.Size(155, 21);
            this.cbNiveau.TabIndex = 36;
            this.cbNiveau.SelectedIndexChanged += new System.EventHandler(this.cbNiveau_SelectedIndexChanged);
            // 
            // FrmAjoutClasse
            // 
            this.ClientSize = new System.Drawing.Size(442, 302);
            this.Controls.Add(this.cbNiveau);
            this.Controls.Add(this.lblNiveau);
            this.Controls.Add(this.logoStVincent);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.labelNaissanceEleve);
            this.Controls.Add(this.labelPrenomEleve);
            this.Controls.Add(this.labelCom);
            this.Controls.Add(this.labelClasseEleve);
            this.Controls.Add(this.labelNomEleve);
            this.Controls.Add(this.textNomClasse);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.label1);
            this.Name = "FrmAjoutClasse";
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmGestionClasses GestionClasses = new FrmGestionClasses();
            GestionClasses.Show();
            this.Hide();
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voulez-vous ajouter un programme, en .pdf, à cette classe ?", "Ajout", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                OpenFileDialog selectFichier = new OpenFileDialog();
                selectFichier.Filter = "Fichiers PDF (*.pdf)|*.pdf";
                selectFichier.Title = "Selectionnez un emploi du temps au format PDF";

                if (selectFichier.ShowDialog() == DialogResult.OK)
                {
                    GestionClasses.CreerUneClasseAvecEDT(textNomClasse.Text.ToString(), selectFichier.FileName, this.idNiveau);
                }
                else
                {
                    GestionClasses.CreerUneClasseSansEDT(textNomClasse.Text.ToString(), this.idNiveau);
                }

                FrmGestionClasses gestionClasse = new FrmGestionClasses();
                gestionClasse.Show();
                this.Hide();
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {

        }

        private void cbNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = cbNiveau.SelectedIndex;

            if (ind != -1)
            {
                this.idNiveau = Convert.ToInt32(((ComboBoxItem)cbNiveau.Items[ind]).Value);
            }

            btnEnregistrer.Enabled = true;
        }

        private void btnRetour_Click_1(object sender, EventArgs e)
        {
            FrmGestionClasses gestionClasses = new FrmGestionClasses();
            gestionClasses.Show();
            this.Hide();
        }
    }
}
