﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using InfirmerieBO;

namespace InfirmerieGUI
{
    public partial class FrmGestionVisites : Form
    {
        private Label titreGestionInfirmerie;
        private Button button1;
        private Label lblEleve;
        private Label lblClasse;
        private ComboBox listeEleves;
        private ComboBox listeClasses;
        private Button btnCreerVisite;
        private Button btnConsulter;
        private Label label1;
        private PictureBox logoStVincent;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }
    
        public FrmGestionVisites()
        {
            InitializeComponent();

            GestionInfirmerie classes = new GestionInfirmerie();
            List<string> lesClasses = new List<string>();

            lesClasses = classes.recupererInfosClasses();
            listeClasses.DataSource = lesClasses;

            GestionInfirmerie eleves = new GestionInfirmerie();
            List<string> lesEleves = new List<string>();

            //string libClasse = Convert.ToString(listeClasses.ValueMember);
            string libClasse = Convert.ToString(listeClasses.SelectedItem);

            List<Eleve> lesEleves2 = new List<Eleve>();
            lesEleves2 = eleves.recupererLesEleves(libClasse);

            foreach (Eleve unEleve in lesEleves2)
            {
                //lesEleves.Add(unEleve.Prenom + " " + unEleve.Nom);
                //listeEleves.Items.Add(unEleve);

                listeEleves.Items.Add(new ComboBoxItem(unEleve.Id, unEleve.Prenom + " " + unEleve.Nom));
            }

            listeClasses.SelectedIndex = -1;

            listeEleves.Enabled = false;

            btnCreerVisite.Enabled = false;

            btnConsulter.Enabled = false;
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGestionVisites));
            this.titreGestionInfirmerie = new System.Windows.Forms.Label();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblEleve = new System.Windows.Forms.Label();
            this.lblClasse = new System.Windows.Forms.Label();
            this.listeEleves = new System.Windows.Forms.ComboBox();
            this.listeClasses = new System.Windows.Forms.ComboBox();
            this.btnCreerVisite = new System.Windows.Forms.Button();
            this.btnConsulter = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            this.SuspendLayout();
            // 
            // titreGestionInfirmerie
            // 
            this.titreGestionInfirmerie.AutoSize = true;
            this.titreGestionInfirmerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreGestionInfirmerie.Location = new System.Drawing.Point(154, 70);
            this.titreGestionInfirmerie.Name = "titreGestionInfirmerie";
            this.titreGestionInfirmerie.Size = new System.Drawing.Size(163, 18);
            this.titreGestionInfirmerie.TabIndex = 8;
            this.titreGestionInfirmerie.Text = "Gestion d\'une infirmerie";
            // 
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(213, 12);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 6;
            this.logoStVincent.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(385, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Retour";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblEleve
            // 
            this.lblEleve.AutoSize = true;
            this.lblEleve.Location = new System.Drawing.Point(135, 179);
            this.lblEleve.Name = "lblEleve";
            this.lblEleve.Size = new System.Drawing.Size(40, 13);
            this.lblEleve.TabIndex = 39;
            this.lblEleve.Text = "Elève :";
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblClasse.Location = new System.Drawing.Point(135, 133);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(44, 13);
            this.lblClasse.TabIndex = 38;
            this.lblClasse.Text = "Classe :";
            // 
            // listeEleves
            // 
            this.listeEleves.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listeEleves.FormattingEnabled = true;
            this.listeEleves.Location = new System.Drawing.Point(185, 179);
            this.listeEleves.Name = "listeEleves";
            this.listeEleves.Size = new System.Drawing.Size(121, 21);
            this.listeEleves.TabIndex = 41;
            this.listeEleves.SelectedIndexChanged += new System.EventHandler(this.listeEleves_SelectedIndexChanged_1);
            // 
            // listeClasses
            // 
            this.listeClasses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listeClasses.FormattingEnabled = true;
            this.listeClasses.Location = new System.Drawing.Point(185, 130);
            this.listeClasses.Name = "listeClasses";
            this.listeClasses.Size = new System.Drawing.Size(121, 21);
            this.listeClasses.TabIndex = 40;
            this.listeClasses.SelectedIndexChanged += new System.EventHandler(this.listeClasses_SelectedIndexChanged_1);
            // 
            // btnCreerVisite
            // 
            this.btnCreerVisite.Location = new System.Drawing.Point(138, 248);
            this.btnCreerVisite.Name = "btnCreerVisite";
            this.btnCreerVisite.Size = new System.Drawing.Size(90, 33);
            this.btnCreerVisite.TabIndex = 43;
            this.btnCreerVisite.Text = "Créer";
            this.btnCreerVisite.UseVisualStyleBackColor = true;
            this.btnCreerVisite.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnConsulter
            // 
            this.btnConsulter.Location = new System.Drawing.Point(253, 248);
            this.btnConsulter.Name = "btnConsulter";
            this.btnConsulter.Size = new System.Drawing.Size(89, 33);
            this.btnConsulter.TabIndex = 44;
            this.btnConsulter.Text = "Consulter";
            this.btnConsulter.UseVisualStyleBackColor = true;
            this.btnConsulter.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(220, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 45;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // FrmGestionVisites
            // 
            this.ClientSize = new System.Drawing.Size(474, 306);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnConsulter);
            this.Controls.Add(this.btnCreerVisite);
            this.Controls.Add(this.listeEleves);
            this.Controls.Add(this.listeClasses);
            this.Controls.Add(this.lblEleve);
            this.Controls.Add(this.lblClasse);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.titreGestionInfirmerie);
            this.Controls.Add(this.logoStVincent);
            this.Name = "FrmGestionVisites";
            this.Load += new System.EventHandler(this.FrmGestionVisites_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }


        private void FrmGestionVisites_Load(object sender, EventArgs e)
        {

        }

        private void listeClasses_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            GestionInfirmerie eleves = new GestionInfirmerie();
            List<string> lesEleves = new List<string>();

            string libClasse = Convert.ToString(listeClasses.SelectedItem);

            listeEleves.Items.Clear();

            List<Eleve> lesEleves2 = new List<Eleve>();
            lesEleves2 = eleves.recupererLesEleves(libClasse);

            foreach (Eleve unEleve in lesEleves2)
            {
                listeEleves.Items.Add(new ComboBoxItem(unEleve.Id, unEleve.Prenom + " " + unEleve.Nom));
            }

            listeEleves.Enabled = true;
        }

        private void listeEleves_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int ind = listeEleves.SelectedIndex;

            if (ind != -1)
            {
                label1.Text = ((ComboBoxItem)listeEleves.Items[ind]).Value.ToString();
            }

            btnCreerVisite.Enabled = true;
            btnConsulter.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //string prenomEleve = comboBoxPrenoms.Text;
            //string nomEleve = listeEleves.Text;
            //string classeEleve = listeClasses.Text;
            int classeEleve = listeClasses.SelectedIndex;

            int idEleve = Convert.ToInt32(label1.Text);
            FrmAjoutVisite ajoutVisite = new FrmAjoutVisite(idEleve, classeEleve);
            ajoutVisite.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int idEleve = Convert.ToInt32(label1.Text);

            FrmListeVisites listeVisites = new FrmListeVisites(idEleve);
            listeVisites.Show();
            this.Hide();
        }
    }
}
