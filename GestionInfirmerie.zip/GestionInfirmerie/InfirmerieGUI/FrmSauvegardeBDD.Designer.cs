﻿namespace InfirmerieGUI
{
    partial class FrmSauvegardeBDD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRetour = new System.Windows.Forms.Button();
            this.buttonVal = new System.Windows.Forms.Button();
            this.buttonParc = new System.Windows.Forms.Button();
            this.textBoxLoc = new System.Windows.Forms.TextBox();
            this.labelLoc = new System.Windows.Forms.Label();
            this.labelBdd = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonRetour
            // 
            this.buttonRetour.Location = new System.Drawing.Point(405, 14);
            this.buttonRetour.Name = "buttonRetour";
            this.buttonRetour.Size = new System.Drawing.Size(75, 23);
            this.buttonRetour.TabIndex = 11;
            this.buttonRetour.Text = "Retour";
            this.buttonRetour.UseVisualStyleBackColor = true;
            this.buttonRetour.Click += new System.EventHandler(this.buttonRetour_Click);
            // 
            // buttonVal
            // 
            this.buttonVal.Enabled = false;
            this.buttonVal.Location = new System.Drawing.Point(405, 111);
            this.buttonVal.Name = "buttonVal";
            this.buttonVal.Size = new System.Drawing.Size(75, 23);
            this.buttonVal.TabIndex = 10;
            this.buttonVal.Text = "Valider";
            this.buttonVal.UseVisualStyleBackColor = true;
            this.buttonVal.Click += new System.EventHandler(this.buttonVal_Click);
            // 
            // buttonParc
            // 
            this.buttonParc.Location = new System.Drawing.Point(405, 69);
            this.buttonParc.Name = "buttonParc";
            this.buttonParc.Size = new System.Drawing.Size(75, 23);
            this.buttonParc.TabIndex = 9;
            this.buttonParc.Text = "Parcourir";
            this.buttonParc.UseVisualStyleBackColor = true;
            this.buttonParc.Click += new System.EventHandler(this.buttonParc_Click);
            // 
            // textBoxLoc
            // 
            this.textBoxLoc.Location = new System.Drawing.Point(84, 71);
            this.textBoxLoc.Name = "textBoxLoc";
            this.textBoxLoc.Size = new System.Drawing.Size(298, 20);
            this.textBoxLoc.TabIndex = 8;
            // 
            // labelLoc
            // 
            this.labelLoc.AutoSize = true;
            this.labelLoc.Location = new System.Drawing.Point(24, 74);
            this.labelLoc.Name = "labelLoc";
            this.labelLoc.Size = new System.Drawing.Size(54, 13);
            this.labelLoc.TabIndex = 7;
            this.labelLoc.Text = "Location :";
            // 
            // labelBdd
            // 
            this.labelBdd.AutoSize = true;
            this.labelBdd.Location = new System.Drawing.Point(24, 24);
            this.labelBdd.Name = "labelBdd";
            this.labelBdd.Size = new System.Drawing.Size(176, 13);
            this.labelBdd.TabIndex = 6;
            this.labelBdd.Text = "Sauvegarde de la base de données";
            // 
            // FrmSauvegardeBDD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 150);
            this.Controls.Add(this.buttonRetour);
            this.Controls.Add(this.buttonVal);
            this.Controls.Add(this.buttonParc);
            this.Controls.Add(this.textBoxLoc);
            this.Controls.Add(this.labelLoc);
            this.Controls.Add(this.labelBdd);
            this.Name = "FrmSauvegardeBDD";
            this.Text = "FrmSauvegardeBDD";
            this.Load += new System.EventHandler(this.FrmSauvegardeBDD_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonRetour;
        private System.Windows.Forms.Button buttonVal;
        private System.Windows.Forms.Button buttonParc;
        private System.Windows.Forms.TextBox textBoxLoc;
        private System.Windows.Forms.Label labelLoc;
        private System.Windows.Forms.Label labelBdd;
    }
}