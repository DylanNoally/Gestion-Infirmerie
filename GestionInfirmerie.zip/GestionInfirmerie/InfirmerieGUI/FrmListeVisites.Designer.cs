﻿namespace InfirmerieGUI
{
    partial class FrmListeVisites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmListeVisites));
            this.lblClasse = new System.Windows.Forms.Label();
            this.titreGestionInfirmerie = new System.Windows.Forms.Label();
            this.btnFiltrer = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            this.listVisites = new System.Windows.Forms.ListBox();
            this.btnConsulter = new System.Windows.Forms.Button();
            this.mtxtIdVisite = new System.Windows.Forms.MaskedTextBox();
            this.dtpSearch = new System.Windows.Forms.DateTimePicker();
            this.btnToutAfficher = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            this.SuspendLayout();
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblClasse.Location = new System.Drawing.Point(318, 162);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(35, 13);
            this.lblClasse.TabIndex = 48;
            this.lblClasse.Text = "Mois :";
            // 
            // titreGestionInfirmerie
            // 
            this.titreGestionInfirmerie.AutoSize = true;
            this.titreGestionInfirmerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreGestionInfirmerie.Location = new System.Drawing.Point(200, 68);
            this.titreGestionInfirmerie.Name = "titreGestionInfirmerie";
            this.titreGestionInfirmerie.Size = new System.Drawing.Size(120, 18);
            this.titreGestionInfirmerie.TabIndex = 46;
            this.titreGestionInfirmerie.Text = "Listes de visites :";
            // 
            // btnFiltrer
            // 
            this.btnFiltrer.Location = new System.Drawing.Point(321, 191);
            this.btnFiltrer.Name = "btnFiltrer";
            this.btnFiltrer.Size = new System.Drawing.Size(194, 28);
            this.btnFiltrer.TabIndex = 55;
            this.btnFiltrer.Text = "Filtrer";
            this.btnFiltrer.UseVisualStyleBackColor = true;
            this.btnFiltrer.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(442, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 57;
            this.button2.Text = "Retour";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(68, 35);
            this.dgv.TabIndex = 58;
            this.dgv.Visible = false;
            // 
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(239, 12);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 45;
            this.logoStVincent.TabStop = false;
            // 
            // listVisites
            // 
            this.listVisites.FormattingEnabled = true;
            this.listVisites.HorizontalScrollbar = true;
            this.listVisites.Location = new System.Drawing.Point(12, 123);
            this.listVisites.Name = "listVisites";
            this.listVisites.Size = new System.Drawing.Size(282, 251);
            this.listVisites.TabIndex = 59;
            this.listVisites.SelectedIndexChanged += new System.EventHandler(this.listVisites_SelectedIndexChanged);
            // 
            // btnConsulter
            // 
            this.btnConsulter.Location = new System.Drawing.Point(321, 312);
            this.btnConsulter.Name = "btnConsulter";
            this.btnConsulter.Size = new System.Drawing.Size(194, 37);
            this.btnConsulter.TabIndex = 60;
            this.btnConsulter.Text = "Consulter";
            this.btnConsulter.UseVisualStyleBackColor = true;
            this.btnConsulter.Click += new System.EventHandler(this.btnConsulter_Click);
            // 
            // mtxtIdVisite
            // 
            this.mtxtIdVisite.Location = new System.Drawing.Point(13, 97);
            this.mtxtIdVisite.Name = "mtxtIdVisite";
            this.mtxtIdVisite.Size = new System.Drawing.Size(100, 20);
            this.mtxtIdVisite.TabIndex = 61;
            this.mtxtIdVisite.Visible = false;
            // 
            // dtpSearch
            // 
            this.dtpSearch.CustomFormat = "MMM- yyyy";
            this.dtpSearch.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpSearch.Location = new System.Drawing.Point(358, 156);
            this.dtpSearch.Name = "dtpSearch";
            this.dtpSearch.ShowUpDown = true;
            this.dtpSearch.Size = new System.Drawing.Size(157, 20);
            this.dtpSearch.TabIndex = 62;
            // 
            // btnToutAfficher
            // 
            this.btnToutAfficher.Location = new System.Drawing.Point(321, 235);
            this.btnToutAfficher.Name = "btnToutAfficher";
            this.btnToutAfficher.Size = new System.Drawing.Size(194, 28);
            this.btnToutAfficher.TabIndex = 63;
            this.btnToutAfficher.Text = "Tout afficher";
            this.btnToutAfficher.UseVisualStyleBackColor = true;
            this.btnToutAfficher.Click += new System.EventHandler(this.button3_Click);
            // 
            // FrmListeVisites
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 386);
            this.Controls.Add(this.btnToutAfficher);
            this.Controls.Add(this.dtpSearch);
            this.Controls.Add(this.mtxtIdVisite);
            this.Controls.Add(this.btnConsulter);
            this.Controls.Add(this.listVisites);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnFiltrer);
            this.Controls.Add(this.lblClasse);
            this.Controls.Add(this.titreGestionInfirmerie);
            this.Controls.Add(this.logoStVincent);
            this.Name = "FrmListeVisites";
            this.Text = "FrmListeVisites";
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblClasse;
        private System.Windows.Forms.Label titreGestionInfirmerie;
        private System.Windows.Forms.PictureBox logoStVincent;
        private System.Windows.Forms.Button btnFiltrer;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.ListBox listVisites;
        private System.Windows.Forms.Button btnConsulter;
        private System.Windows.Forms.MaskedTextBox mtxtIdVisite;
        private System.Windows.Forms.DateTimePicker dtpSearch;
        private System.Windows.Forms.Button btnToutAfficher;

    }
}