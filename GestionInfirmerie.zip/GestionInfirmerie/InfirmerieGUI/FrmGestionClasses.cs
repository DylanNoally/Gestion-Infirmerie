﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using InfirmerieBO;

namespace InfirmerieGUI
{
    public partial class FrmGestionClasses : Form
    {
        private int idClasse;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmGestionClasses()
        {
            InitializeComponent();

            List<Classe> lesClasses = new List<Classe>();
            lesClasses = GestionClasses.GetListeDesClasses();

            foreach (Classe uneClasse in lesClasses)
            {
                listeClasses.Items.Add(new ComboBoxItem(uneClasse.Id, uneClasse.Libelle));
            }

            btnModifier.Enabled = false;
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void titreGestionInfirmerie_Click(object sender, EventArgs e)
        {

        }

        private void btnCreerClasse_Click(object sender, EventArgs e)
        {
            FrmAjoutClasse ajoutClasse = new FrmAjoutClasse();
            ajoutClasse.Show();
            this.Hide();
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            
        }

        private void FrmGestionClasses_Load(object sender, EventArgs e)
        {

        }

        private void listeClasses_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblClasse_Click(object sender, EventArgs e)
        {

        }

        private void logoStVincent_Click(object sender, EventArgs e)
        {

        }

        private void listeClasses_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            int ind = listeClasses.SelectedIndex;

            if (ind != -1)
            {
                this.idClasse = Convert.ToInt32(((ComboBoxItem)listeClasses.Items[ind]).Value);
            }

            btnModifier.Enabled = true;
        }

        private void btnModifier_Click_1(object sender, EventArgs e)
        {
            FrmModifierClasse ModifClasse = new FrmModifierClasse(idClasse);
            ModifClasse.Show();
            this.Hide();
        }

        private void btnRetour_Click_1(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }
    }
}
