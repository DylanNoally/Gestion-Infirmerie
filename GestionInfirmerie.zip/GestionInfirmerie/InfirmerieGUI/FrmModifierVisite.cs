﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using InfirmerieBO;

namespace InfirmerieGUI
{
    public partial class FrmModifierVisite : Form
    {
        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        private int idVisiteChoisie;
        private int idEleveChoisi;

        public FrmModifierVisite(int idVisite, int idEleve)
        {
            InitializeComponent();

            this.idVisiteChoisie = idVisite;
            this.idEleveChoisi = idEleve;

            Visite visiteChoisie = GestionVisites.GetUneVisite(idVisiteChoisie);

            txtMotif.Text = visiteChoisie.MotifVisite;
            commentSante.Text = visiteChoisie.Commentaire;

            dtpEntree.Value = visiteChoisie.HeureArrive;
            dtpSortie.Value = visiteChoisie.HeureDepart;

            if (visiteChoisie.Status == "1")
            {
                rbDomicile.Checked = true;
            }

            if (visiteChoisie.Status == "2")
            {
                rbHopital.Checked = true;
            }

            if (visiteChoisie.ParentsPrevenus == true)
            {
                cbParents.Checked = true;
            }

            nupPouls.Value = Convert.ToInt32(visiteChoisie.Pouls);
            nupQte.Value = visiteChoisie.Qte;

            List<int> lesIdMedics = new List<int>();
            lesIdMedics = GestionVisites.GetListeIdMedicamentsLies(idVisiteChoisie);

            GestionMedicaments medicGestion = new GestionMedicaments();
            List<Medicament> lesMedics = new List<Medicament>();
            lesMedics = medicGestion.RecuperersLesInfosMedicaments();

            int ind = 0;
            foreach (Medicament unMedic in lesMedics)
            {
                clbMedicaments.Items.Add(new ComboBoxItem(unMedic.Id, unMedic.Libelle));
                for (int i = 0; i <= (lesIdMedics.Count - 1); i++)
                {
                    {
                        if (unMedic.Id == lesIdMedics[i])
                        {
                            clbMedicaments.SetItemChecked(ind, true);
                        }
                    }
                }
                ind++;
            }
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmListeVisites listeVisites = new FrmListeVisites(idEleveChoisi);
            listeVisites.Show();
            this.Hide();
        }

        private void btnSuppress_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Voulez-vous vraiment supprimer cette visite ?", "Attention !", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                GestionVisites.DeleteUneVisite(idVisiteChoisie);
                MessageBox.Show("Suppression de la visite effectuée");
                FrmListeVisites listeVisites = new FrmListeVisites(idEleveChoisi);
                listeVisites.Show();
                this.Hide();
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            string statut = "";
            string pouls = (nupPouls.Value).ToString();

            if (rbDomicile.Checked == true)
            {
                statut="à son domicile";
            }

            if (rbHopital.Checked == true)
            {
                statut = "à l'hôpital";
            }

            Visite uneVisite = new Visite(idVisiteChoisie, dtpEntree.Value, dtpSortie.Value, txtMotif.Text, commentSante.Text, pouls, Convert.ToInt32(nupQte.Value), statut, cbParents.Checked);

            GestionVisites.UpdateVisite(uneVisite);

            GestionVisites.DeleteAllMedVis(idVisiteChoisie);

            List<int> lesMedics = new List<int>();

            for (int i = 0; i <= (clbMedicaments.Items.Count - 1); i++)
            {
                if (clbMedicaments.GetItemChecked(i))
                {
                    GestionVisites.LierMedicVisite(((ComboBoxItem)clbMedicaments.Items[i]).Value, idVisiteChoisie);
                }
            }

            MessageBox.Show("Visite modifiée");
            FrmListeVisites listeVisites = new FrmListeVisites(idEleveChoisi);
            listeVisites.Show();
            this.Hide();
        }
    }
}
