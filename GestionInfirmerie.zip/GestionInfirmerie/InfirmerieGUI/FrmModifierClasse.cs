﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmModifierClasse : Form
    {
        public FrmModifierClasse(int id)
        {
            InitializeComponent();

            // Récupération de la chaîne de connexion à la BD à l'ouverture du formulaire
            GestionUtilisateurs.SetchaineConnexion(ConfigurationManager.ConnectionStrings["Infirmerie"]);


            // txtIdMedicament.Text = id.ToString();

            // -------------------------------------------------------------------------------------------
            // Compare ce qui a été passé à partir de la liste déroulante avec ce qu'il y a dans la BDD
            // afin d'éviter une quelconque erreur de la réactualisation de la liste déroulante
            // -------------------------------------------------------------------------------------------
            int requeteComparaison;
            requeteComparaison = GestionClasses.VerifClasse(id);

            if (requeteComparaison != 1)
            {
                // ---------------------------------------------------------------------------------------------
                // Si la requête ne trouve pas le médicament passé par la liste cela affiche un message d'erreur 
                // et renvoie sur le formulaire précédent afin de resélectionner
                // ---------------------------------------------------------------------------------------------
                MessageBox.Show("Une erreur s'est produite, réessayer de modifier la classe !");
                FrmGestionClasses GestionClasse = new FrmGestionClasses();
                GestionClasse.Show();
                this.Hide();
            }
            else
            {
                Classe uneClasse;
                uneClasse = GestionClasses.ExtractInfosClasse(id);

                txtIdClasse.Text = uneClasse.Id.ToString();
                txtLblClasse.Text = uneClasse.Libelle.ToString();
            }
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmGestionClasses GestionClasses = new FrmGestionClasses();
            GestionClasses.Show();
            this.Hide();
        }

        private void FrmModifierClasse_Load(object sender, EventArgs e)
        {

        }

        private void btnSuppression_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show(this, "Confirmez-vous la suppression de la classe : " + txtLblClasse.Text + " ?", "Votre attention est requise !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                // Variable qui récupère la valeur retourner de la méthode de suppression d'un médicament au clic du bouton "Supprimer"
                int requeteDeleteReussi = GestionClasses.SuppressionClasse(int.Parse(txtIdClasse.Text));

                // Si la variable retourne 0 (false), alors une erreur s'est produite, sinon la suppresion s'est bien passée
                if (requeteDeleteReussi != 1 && requeteDeleteReussi != 2)
                {
                    MessageBox.Show("Une erreur s'est produite, vérifier qu'aucun élève n'est associé à cette classe et réessayer de supprimer cette classe !");
                    // Redirection vers le formulaire contenant la liste des médicaments si l'utilisateur est sûr
                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }

                if (requeteDeleteReussi == 2)
                {
                    MessageBox.Show(this, "Attention au moins un élève est associé à cette classe, supprimez d'abord les élèves associés à cette classe avant de la supprimer !", "Votre attention est requise !", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    // Redirection vers le formulaire contenant la liste des médicaments si l'utilisateur est sûr
                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("La classe : " + txtLblClasse.Text + " a bien été supprimé !");

                    // Redirection vers le formulaire contenant la liste des médicaments si l'utilisateur est sûr
                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }
            }
        }

        private void btnValider_Click(object sender, EventArgs e)
        {

        }
    }
}
