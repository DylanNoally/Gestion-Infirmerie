﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmModifierClasse : Form
    {
        private int idNiveau;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmModifierClasse(int id)
        {
            InitializeComponent();
            
            // -------------------------------------------------------------------------------------------
            // Compare ce qui a été passé à partir de la liste déroulante avec ce qu'il y a dans la BDD
            // afin d'éviter une quelconque erreur de la réactualisation de la liste déroulante
            // -------------------------------------------------------------------------------------------
            int requeteComparaison;
            requeteComparaison = GestionClasses.VerifClasse(id);

            if (requeteComparaison != 1)
            {
                // ---------------------------------------------------------------------------------------------
                // Si la requête ne trouve pas le médicament passé par la liste cela affiche un message d'erreur 
                // et renvoie sur le formulaire précédent afin de resélectionner
                // ---------------------------------------------------------------------------------------------
                MessageBox.Show("Une erreur s'est produite, réessayer de modifier la classe !");
                FrmGestionClasses GestionClasse = new FrmGestionClasses();
                GestionClasse.Show();
                this.Hide();
            }
            else
            {
                Classe uneClasse;
                uneClasse = GestionClasses.ExtractInfosClasse(id);

                txtIdClasse.Text = uneClasse.Id.ToString();
                txtLblClasse.Text = uneClasse.Libelle.ToString();

                List<Niveau> lesNiveaux = new List<Niveau>();
                lesNiveaux = GestionClasses.GetListeDesNiveaux();

                foreach (Niveau unNiveau in lesNiveaux)
                {
                    cbNiveau.Items.Add(new ComboBoxItem(unNiveau.Id, unNiveau.Libelle));
                }

                int ind = 0;
                bool trouve = false;

                while (ind < cbNiveau.Items.Count-1 || trouve == false)
                {
                    if (((ComboBoxItem)cbNiveau.Items[ind]).Value == uneClasse.IdNiveau)
                    {
                        cbNiveau.SelectedIndex = ind;
                        trouve = true;
                    }
                    ind++;
                } 
            }
        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmGestionClasses GestionClasses = new FrmGestionClasses();
            GestionClasses.Show();
            this.Hide();
        }

        private void FrmModifierClasse_Load(object sender, EventArgs e)
        {

        }

        private void btnSuppression_Click(object sender, EventArgs e)
        {

           
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voulez-vous ajouter un programme, en .pdf, à cette classe ?", "Ajout", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                OpenFileDialog selectFichier = new OpenFileDialog();
                selectFichier.Filter = "Fichiers PDF (*.pdf)|*.pdf";
                selectFichier.Title = "Selectionnez un emploi du temps au format PDF";

                if (selectFichier.ShowDialog() == DialogResult.OK)
                {
                    GestionClasses.CreerUneClasseAvecEDT(txtLblClasse.Text.ToString(), selectFichier.FileName, this.idNiveau);
                }
                else
                {
                    GestionClasses.CreerUneClasseSansEDT(txtLblClasse.Text.ToString(), this.idNiveau);
                }

                FrmGestionClasses gestionClasse = new FrmGestionClasses();
                gestionClasse.Show();
                this.Hide();
            }
        }

        private void txtIdClasse_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLblClasse_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModifierClasse_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void txtPlanning_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblClasse_Click(object sender, EventArgs e)
        {

        }

        private void lblPlanning_Click(object sender, EventArgs e)
        {

        }

        private void cbNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = cbNiveau.SelectedIndex;

            if (ind != -1)
            {
                this.idNiveau = Convert.ToInt32(((ComboBoxItem)cbNiveau.Items[ind]).Value);
            }
        }

        private void btnSuppression_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "Confirmez-vous la suppression de la classe : " + txtLblClasse.Text + " ?", "Votre attention est requise !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                // Variable qui récupère la valeur retourner de la méthode de suppression d'un médicament au clic du bouton "Supprimer"
                int requeteDeleteReussi = GestionClasses.SuppressionClasse(int.Parse(txtIdClasse.Text));

                // Si la variable retourne 0 (false), alors une erreur s'est produite, sinon la suppresion s'est bien passée
                if (requeteDeleteReussi != 1 && requeteDeleteReussi != 2)
                {
                    MessageBox.Show("Une erreur s'est produite, vérifier qu'aucun élève n'est associé à cette classe et réessayer de supprimer cette classe !");

                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }

                if (requeteDeleteReussi == 2)
                {
                    MessageBox.Show(this, "Attention au moins un élève est associé à cette classe, supprimez d'abord les élèves associés à cette classe avant de la supprimer !", "Votre attention est requise !", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("La classe : " + txtLblClasse.Text + " a bien été supprimé !");

                    FrmGestionClasses gestionClasses = new FrmGestionClasses();
                    gestionClasses.Show();
                    this.Hide();
                }
            }
        }

        private void btnRetour_Click_1(object sender, EventArgs e)
        {
            FrmGestionClasses gestionClasses = new FrmGestionClasses();
            gestionClasses.Show();
            this.Hide();
        }
    }
}
