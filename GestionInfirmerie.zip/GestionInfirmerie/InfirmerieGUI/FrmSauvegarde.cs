﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using InfirmerieBLL;
using InfirmerieBO;

namespace InfirmerieGUI
{
    public partial class FrmSauvegardeBDD : Form
    {
        SqlConnection con = new SqlConnection("Persist Security Info = False; Trusted_Connection = True;database = BD_Infirmerie; server=SANJI");
        public FrmSauvegardeBDD()
        {
            InitializeComponent();
        }

        private void buttonParc_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonVal_Click(object sender, EventArgs e)
        {
            string database = con.Database.ToString();

            if (textBoxLoc.Text == string.Empty)
            {
                MessageBox.Show("Veuillez entrer l'emplacement du fichier de sauvegarde");
            }
            else
            {
                string lien = "BACKUP DATABASE [" + database + "] TO DISK='" + textBoxLoc.Text + "\\" + "database" + "-" + DateTime.Now.ToString("yyyy-MM-dd--HH-mm-ss") + ".bak'";
                GestionInfirmerie.SauvegardeBDD(lien);

                MessageBox.Show("Sauvegarde de base de données effectuée avec succès");
                FrmAccueil Accueil = new FrmAccueil();
                Accueil.Show();
                this.Hide();
            }
        }

        private void buttonRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Retour = new FrmAccueil();
            Retour.Show();
            this.Hide();
        }

        private void textBoxLoc_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelLoc_Click(object sender, EventArgs e)
        {

        }

        private void labelBdd_Click(object sender, EventArgs e)
        {

        }

        private void buttonRetour_Click_1(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void buttonParc_Click_1(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBoxLoc.Text = dlg.SelectedPath;
                buttonVal.Enabled = true;
            }
        }
    }
}
