﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using System.Configuration;


namespace InfirmerieGUI
{
    public partial class FrmAjoutEleve : Form
    {
        public FrmAjoutEleve()
        {
            InitializeComponent();
            // Récupération de la chaine de connexion à la BD à l'ouverture du formulaire
            GestionInfirmerie.SetChaineConnexion(ConfigurationManager.ConnectionStrings["Infirmerie"]);

            GestionClasses classes = new GestionClasses();
            DataTable lesClasses = new DataTable();
            lesClasses = classes.RecupererInfosClasses();
            listClasseEleve.DataSource = lesClasses;
            listClasseEleve.DisplayMember = "Libelle_classe";
            listClasseEleve.ValueMember = "Id_classe";
        }

        private void FrmAjoutEleve_Load(object sender, EventArgs e)
        {

        }

        private void textNomEleve_TextChanged(object sender, EventArgs e)
        {
            if (textNomEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textPrenomEleve_TextChanged(object sender, EventArgs e)
        {
            if (textPrenomEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textTelParent_TextChanged(object sender, EventArgs e)
        {
            if (textTelParent.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textTelEleve_TextChanged(object sender, EventArgs e)
        {
            if (textTelEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void richTextCom_TextChanged(object sender, EventArgs e)
        {
            if (richTextCom.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }


        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            // Récupère l'id de la classe sélectionné
            int idClasse = Convert.ToInt32(listClasseEleve.SelectedValue.ToString());
            string libelleClasse = listClasseEleve.Text;

            string dateNaissance = dtpNaissanceEleve.Value.ToShortDateString();
            DateTime date = DateTime.Parse(dateNaissance);

            // Appel de la méthode CreerEleve de la couche BLL
            GestionInfirmerie.CreerEleve(textNomEleve.Text, textPrenomEleve.Text, date, richTextCom.Text, textTelEleve.Text, textTelParent.Text, checkTT.Checked, idClasse);

            // Message de dialogue qui confirme l'enregistrement en BD
            MessageBox.Show("Enregistrement de l'élève " + textNomEleve.Text + " " + textPrenomEleve.Text + " dans la classe " + libelleClasse + " effectué !");

            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();

        }

        private void checkTT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkTT.Checked == true)
            {
                btnEnregistrer.Enabled = true;
            }
            else
            {
                btnEnregistrer.Enabled = false;
            }
        }

        private void listClasseEleve_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textNaissance_TextChanged(object sender, EventArgs e)
        {

        }

        //private void checkArchive_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkArchive.Checked == false)
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //}

        //private void checkVisite_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkVisite.Checked == false)
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //}

        //private void listClasseEleve_SelectedIndexChanged_1(object sender, EventArgs e)
        //{
        //    if (listClasseEleve.DataSource == string.Empty)
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //}

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }
    }
}
