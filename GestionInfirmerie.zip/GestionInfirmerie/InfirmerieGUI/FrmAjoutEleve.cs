﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using System.Configuration;
using InfirmerieBO;


namespace InfirmerieGUI
{
    public partial class FrmAjoutEleve : Form
    {
        private int idClasse;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmAjoutEleve()
        {
            InitializeComponent();

            List<Classe> lesClasses = new List<Classe>();
            lesClasses = GestionClasses.GetListeDesClasses();

            foreach (Classe uneClasse in lesClasses)
            {
                cbListeClasse.Items.Add(new ComboBoxItem(uneClasse.Id, uneClasse.Libelle));
            }
        }

        private void FrmAjoutEleve_Load(object sender, EventArgs e)
        {

        }

        private void textNomEleve_TextChanged(object sender, EventArgs e)
        {
            if (textNomEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textPrenomEleve_TextChanged(object sender, EventArgs e)
        {
            if (textPrenomEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textTelParent_TextChanged(object sender, EventArgs e)
        {
            if (textTelParent.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void textTelEleve_TextChanged(object sender, EventArgs e)
        {
            if (textTelEleve.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void richTextCom_TextChanged(object sender, EventArgs e)
        {
            if (richTextCom.Text == string.Empty)
            {
                btnEnregistrer.Enabled = false;
            }
            else
            {
                btnEnregistrer.Enabled = true;
            }
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            // Appel de la méthode CreerEleve de la couche BLL
            GestionInfirmerie.CreerEleve(textNomEleve.Text, textPrenomEleve.Text, dTPDateNaissance.Value, richTextCom.Text, textTelEleve.Text, textTelParent.Text, false, checkTT.Checked, false, (cbListeClasse.SelectedIndex+1));

            // Message de dialogue qui confirme l'enregistrement en BD
            MessageBox.Show("Enregistrement de l'élève effectué !", "Saisie");

            FrmAccueil Accueil = new FrmAccueil();
            this.Close();
            Accueil.Show();
        }



        private void checkTT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkTT.Checked == true)
            {
                btnEnregistrer.Enabled = true;
            }
            else
            {
                btnEnregistrer.Enabled = false;
            }
        }

        private void listClasseEleve_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private void checkArchive_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkArchive.Checked == false)
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //}

        //private void checkVisite_CheckedChanged(object sender, EventArgs e)
        //{
        //    if (checkVisite.Checked == false)
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //}

        //private void listClasseEleve_SelectedIndexChanged_1(object sender, EventArgs e)
        //{
        //    if (listClasseEleve.DataSource == string.Empty)
        //    {
        //        btnEnregistrer.Enabled = false;
        //    }
        //    else
        //    {
        //        btnEnregistrer.Enabled = true;
        //    }
        //}

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmAccueil Accueil = new FrmAccueil();
            Accueil.Show();
            this.Hide();
        }

        private void cbListeClasse_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = cbListeClasse.SelectedIndex;

            if (ind != -1)
            {
                this.idClasse = Convert.ToInt32(((ComboBoxItem)cbListeClasse.Items[ind]).Value);
            }
        }
    }
}
