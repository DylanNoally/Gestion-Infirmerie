﻿namespace InfirmerieGUI
{
    partial class FrmStats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmStats));
            this.titreGestionInfirmerie = new System.Windows.Forms.Label();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            this.titreAccueil = new System.Windows.Forms.Label();
            this.btnGestionEleves = new System.Windows.Forms.Button();
            this.btnRetour = new System.Windows.Forms.Button();
            this.dtpDateDebutVisites = new System.Windows.Forms.DateTimePicker();
            this.dtpDateFinVisites = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.errorPeriodeInfo = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorPeriode = new System.Windows.Forms.ErrorProvider(this.components);
            this.buttonNbTotalVisite = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriodeInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriode)).BeginInit();
            this.SuspendLayout();
            // 
            // titreGestionInfirmerie
            // 
            this.titreGestionInfirmerie.AutoSize = true;
            this.titreGestionInfirmerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreGestionInfirmerie.Location = new System.Drawing.Point(251, 59);
            this.titreGestionInfirmerie.Name = "titreGestionInfirmerie";
            this.titreGestionInfirmerie.Size = new System.Drawing.Size(163, 18);
            this.titreGestionInfirmerie.TabIndex = 8;
            this.titreGestionInfirmerie.Text = "Gestion d\'une infirmerie";
            // 
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(308, 12);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 6;
            this.logoStVincent.TabStop = false;
            // 
            // titreAccueil
            // 
            this.titreAccueil.AutoSize = true;
            this.titreAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreAccueil.Location = new System.Drawing.Point(282, 93);
            this.titreAccueil.Name = "titreAccueil";
            this.titreAccueil.Size = new System.Drawing.Size(93, 20);
            this.titreAccueil.TabIndex = 7;
            this.titreAccueil.Text = "Statistiques";
            // 
            // btnGestionEleves
            // 
            this.btnGestionEleves.Location = new System.Drawing.Point(377, 146);
            this.btnGestionEleves.Name = "btnGestionEleves";
            this.btnGestionEleves.Size = new System.Drawing.Size(168, 45);
            this.btnGestionEleves.TabIndex = 9;
            this.btnGestionEleves.Text = "Nombre moyen de médicaments donnés par visite";
            this.btnGestionEleves.UseVisualStyleBackColor = true;
            this.btnGestionEleves.Click += new System.EventHandler(this.btnGestionEleves_Click);
            // 
            // btnRetour
            // 
            this.btnRetour.Location = new System.Drawing.Point(564, 12);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(75, 23);
            this.btnRetour.TabIndex = 78;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = true;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // dtpDateDebutVisites
            // 
            this.dtpDateDebutVisites.Location = new System.Drawing.Point(58, 269);
            this.dtpDateDebutVisites.Name = "dtpDateDebutVisites";
            this.dtpDateDebutVisites.Size = new System.Drawing.Size(200, 20);
            this.dtpDateDebutVisites.TabIndex = 79;
            this.dtpDateDebutVisites.ValueChanged += new System.EventHandler(this.dtpDateDebutVisites_ValueChanged);
            // 
            // dtpDateFinVisites
            // 
            this.dtpDateFinVisites.Location = new System.Drawing.Point(399, 269);
            this.dtpDateFinVisites.Name = "dtpDateFinVisites";
            this.dtpDateFinVisites.Size = new System.Drawing.Size(200, 20);
            this.dtpDateFinVisites.TabIndex = 80;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(105, 251);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 18);
            this.label1.TabIndex = 81;
            this.label1.Text = "Date de début :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(445, 251);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 18);
            this.label2.TabIndex = 82;
            this.label2.Text = "Date de fin :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 303);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 49);
            this.button1.TabIndex = 83;
            this.button1.Text = "Nombre de visites moyennes par élève selon la période";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(250, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 20);
            this.label3.TabIndex = 84;
            this.label3.Text = "Sélection d\'une période";
            // 
            // errorPeriodeInfo
            // 
            this.errorPeriodeInfo.ContainerControl = this;
            // 
            // errorPeriode
            // 
            this.errorPeriode.ContainerControl = this;
            // 
            // buttonNbTotalVisite
            // 
            this.buttonNbTotalVisite.Location = new System.Drawing.Point(190, 304);
            this.buttonNbTotalVisite.Name = "buttonNbTotalVisite";
            this.buttonNbTotalVisite.Size = new System.Drawing.Size(139, 48);
            this.buttonNbTotalVisite.TabIndex = 85;
            this.buttonNbTotalVisite.Text = "Nombre total de visite selon la période";
            this.buttonNbTotalVisite.UseVisualStyleBackColor = true;
            this.buttonNbTotalVisite.Click += new System.EventHandler(this.buttonNbTotalVisite_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(130, 146);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 45);
            this.button2.TabIndex = 86;
            this.button2.Text = "Nombre d\'élèves total";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(349, 304);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(139, 48);
            this.button3.TabIndex = 87;
            this.button3.Text = "Temps moyen d\'une visite selon la période";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(500, 304);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(139, 48);
            this.button4.TabIndex = 88;
            this.button4.Text = "Nombre total de médicaments données sur l\'année scolaire";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // FrmStats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 371);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.buttonNbTotalVisite);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpDateFinVisites);
            this.Controls.Add(this.dtpDateDebutVisites);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.btnGestionEleves);
            this.Controls.Add(this.titreGestionInfirmerie);
            this.Controls.Add(this.titreAccueil);
            this.Controls.Add(this.logoStVincent);
            this.Name = "FrmStats";
            this.Text = "Stats";
            this.Load += new System.EventHandler(this.FrmStats_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriodeInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titreGestionInfirmerie;
        private System.Windows.Forms.PictureBox logoStVincent;
        private System.Windows.Forms.Label titreAccueil;
        private System.Windows.Forms.Button btnGestionEleves;
        private System.Windows.Forms.Button btnRetour;
        private System.Windows.Forms.DateTimePicker dtpDateDebutVisites;
        private System.Windows.Forms.DateTimePicker dtpDateFinVisites;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ErrorProvider errorPeriodeInfo;
        private System.Windows.Forms.ErrorProvider errorPeriode;
        private System.Windows.Forms.Button buttonNbTotalVisite;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
    }
}