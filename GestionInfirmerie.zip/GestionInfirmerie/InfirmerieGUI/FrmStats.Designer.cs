﻿namespace InfirmerieGUI
{
    partial class FrmStats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmStats));
            this.btnNbTotalMedic = new System.Windows.Forms.Button();
            this.errorPeriodeInfo = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnTempsMoyenVisite = new System.Windows.Forms.Button();
            this.btnElevesTotal = new System.Windows.Forms.Button();
            this.errorPeriode = new System.Windows.Forms.ErrorProvider(this.components);
            this.buttonNbTotalVisite = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnNbreVisitesMoy = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDateFinVisites = new System.Windows.Forms.DateTimePicker();
            this.dtpDateDebutVisites = new System.Windows.Forms.DateTimePicker();
            this.btnRetour = new System.Windows.Forms.Button();
            this.btnGestionEleves = new System.Windows.Forms.Button();
            this.titreGestionInfirmerie = new System.Windows.Forms.Label();
            this.titreAccueil = new System.Windows.Forms.Label();
            this.logoStVincent = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriodeInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).BeginInit();
            this.SuspendLayout();
            // 
            // btnNbTotalMedic
            // 
            this.btnNbTotalMedic.Location = new System.Drawing.Point(23, 392);
            this.btnNbTotalMedic.Name = "btnNbTotalMedic";
            this.btnNbTotalMedic.Size = new System.Drawing.Size(302, 48);
            this.btnNbTotalMedic.TabIndex = 103;
            this.btnNbTotalMedic.Text = "Nombre total de médicaments données sur la période";
            this.btnNbTotalMedic.UseVisualStyleBackColor = true;
            this.btnNbTotalMedic.Click += new System.EventHandler(this.btnNbTotalMedic_Click);
            // 
            // errorPeriodeInfo
            // 
            this.errorPeriodeInfo.ContainerControl = this;
            // 
            // btnTempsMoyenVisite
            // 
            this.btnTempsMoyenVisite.Location = new System.Drawing.Point(378, 392);
            this.btnTempsMoyenVisite.Name = "btnTempsMoyenVisite";
            this.btnTempsMoyenVisite.Size = new System.Drawing.Size(227, 48);
            this.btnTempsMoyenVisite.TabIndex = 102;
            this.btnTempsMoyenVisite.Text = "Temps moyen d\'une visite selon la période";
            this.btnTempsMoyenVisite.UseVisualStyleBackColor = true;
            this.btnTempsMoyenVisite.Click += new System.EventHandler(this.btnTempsMoyenVisite_Click);
            // 
            // btnElevesTotal
            // 
            this.btnElevesTotal.Location = new System.Drawing.Point(134, 152);
            this.btnElevesTotal.Name = "btnElevesTotal";
            this.btnElevesTotal.Size = new System.Drawing.Size(128, 45);
            this.btnElevesTotal.TabIndex = 101;
            this.btnElevesTotal.Text = "Nombre d\'élèves total";
            this.btnElevesTotal.UseVisualStyleBackColor = true;
            this.btnElevesTotal.Click += new System.EventHandler(this.btnElevesTotal_Click);
            // 
            // errorPeriode
            // 
            this.errorPeriode.ContainerControl = this;
            // 
            // buttonNbTotalVisite
            // 
            this.buttonNbTotalVisite.Location = new System.Drawing.Point(378, 323);
            this.buttonNbTotalVisite.Name = "buttonNbTotalVisite";
            this.buttonNbTotalVisite.Size = new System.Drawing.Size(227, 48);
            this.buttonNbTotalVisite.TabIndex = 100;
            this.buttonNbTotalVisite.Text = "Nombre total de visite selon la période";
            this.buttonNbTotalVisite.UseVisualStyleBackColor = true;
            this.buttonNbTotalVisite.Click += new System.EventHandler(this.buttonNbTotalVisite_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(234, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 20);
            this.label3.TabIndex = 99;
            this.label3.Text = "Sélection d\'une période";
            // 
            // btnNbreVisitesMoy
            // 
            this.btnNbreVisitesMoy.Location = new System.Drawing.Point(22, 322);
            this.btnNbreVisitesMoy.Name = "btnNbreVisitesMoy";
            this.btnNbreVisitesMoy.Size = new System.Drawing.Size(303, 49);
            this.btnNbreVisitesMoy.TabIndex = 98;
            this.btnNbreVisitesMoy.Text = "Nombre de visites moyennes par élève selon la période";
            this.btnNbreVisitesMoy.UseVisualStyleBackColor = true;
            this.btnNbreVisitesMoy.Click += new System.EventHandler(this.btnNbreVisitesMoy_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(454, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 18);
            this.label2.TabIndex = 97;
            this.label2.Text = "Date de fin :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(105, 257);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 18);
            this.label1.TabIndex = 96;
            this.label1.Text = "Date de début :";
            // 
            // dtpDateFinVisites
            // 
            this.dtpDateFinVisites.Location = new System.Drawing.Point(392, 278);
            this.dtpDateFinVisites.Name = "dtpDateFinVisites";
            this.dtpDateFinVisites.Size = new System.Drawing.Size(200, 20);
            this.dtpDateFinVisites.TabIndex = 95;
            // 
            // dtpDateDebutVisites
            // 
            this.dtpDateDebutVisites.Location = new System.Drawing.Point(62, 278);
            this.dtpDateDebutVisites.Name = "dtpDateDebutVisites";
            this.dtpDateDebutVisites.Size = new System.Drawing.Size(200, 20);
            this.dtpDateDebutVisites.TabIndex = 94;
            // 
            // btnRetour
            // 
            this.btnRetour.Location = new System.Drawing.Point(559, 18);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(75, 23);
            this.btnRetour.TabIndex = 93;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = true;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click_1);
            // 
            // btnGestionEleves
            // 
            this.btnGestionEleves.Location = new System.Drawing.Point(318, 152);
            this.btnGestionEleves.Name = "btnGestionEleves";
            this.btnGestionEleves.Size = new System.Drawing.Size(259, 45);
            this.btnGestionEleves.TabIndex = 92;
            this.btnGestionEleves.Text = "Nombre moyen de médicaments donnés par visite";
            this.btnGestionEleves.UseVisualStyleBackColor = true;
            this.btnGestionEleves.Click += new System.EventHandler(this.btnGestionEleves_Click);
            // 
            // titreGestionInfirmerie
            // 
            this.titreGestionInfirmerie.AutoSize = true;
            this.titreGestionInfirmerie.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreGestionInfirmerie.Location = new System.Drawing.Point(246, 65);
            this.titreGestionInfirmerie.Name = "titreGestionInfirmerie";
            this.titreGestionInfirmerie.Size = new System.Drawing.Size(163, 18);
            this.titreGestionInfirmerie.TabIndex = 91;
            this.titreGestionInfirmerie.Text = "Gestion d\'une infirmerie";
            // 
            // titreAccueil
            // 
            this.titreAccueil.AutoSize = true;
            this.titreAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titreAccueil.Location = new System.Drawing.Point(277, 99);
            this.titreAccueil.Name = "titreAccueil";
            this.titreAccueil.Size = new System.Drawing.Size(93, 20);
            this.titreAccueil.TabIndex = 90;
            this.titreAccueil.Text = "Statistiques";
            // 
            // logoStVincent
            // 
            this.logoStVincent.ErrorImage = null;
            this.logoStVincent.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.logoStVincent.InitialImage = ((System.Drawing.Image)(resources.GetObject("logoStVincent.InitialImage")));
            this.logoStVincent.Location = new System.Drawing.Point(303, 18);
            this.logoStVincent.Name = "logoStVincent";
            this.logoStVincent.Size = new System.Drawing.Size(42, 44);
            this.logoStVincent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoStVincent.TabIndex = 89;
            this.logoStVincent.TabStop = false;
            // 
            // FrmStats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 461);
            this.Controls.Add(this.btnNbTotalMedic);
            this.Controls.Add(this.btnTempsMoyenVisite);
            this.Controls.Add(this.btnElevesTotal);
            this.Controls.Add(this.buttonNbTotalVisite);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnNbreVisitesMoy);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpDateFinVisites);
            this.Controls.Add(this.dtpDateDebutVisites);
            this.Controls.Add(this.btnRetour);
            this.Controls.Add(this.btnGestionEleves);
            this.Controls.Add(this.titreGestionInfirmerie);
            this.Controls.Add(this.titreAccueil);
            this.Controls.Add(this.logoStVincent);
            this.Name = "FrmStats";
            this.Text = "FrmStats1";
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriodeInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorPeriode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoStVincent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNbTotalMedic;
        private System.Windows.Forms.ErrorProvider errorPeriodeInfo;
        private System.Windows.Forms.Button btnTempsMoyenVisite;
        private System.Windows.Forms.Button btnElevesTotal;
        private System.Windows.Forms.Button buttonNbTotalVisite;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnNbreVisitesMoy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpDateFinVisites;
        private System.Windows.Forms.DateTimePicker dtpDateDebutVisites;
        private System.Windows.Forms.Button btnRetour;
        private System.Windows.Forms.Button btnGestionEleves;
        private System.Windows.Forms.Label titreGestionInfirmerie;
        private System.Windows.Forms.Label titreAccueil;
        private System.Windows.Forms.PictureBox logoStVincent;
        private System.Windows.Forms.ErrorProvider errorPeriode;
    }
}