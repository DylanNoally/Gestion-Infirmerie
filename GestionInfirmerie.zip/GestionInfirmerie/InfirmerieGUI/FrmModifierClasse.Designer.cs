﻿namespace InfirmerieGUI
{
    partial class FrmModifierClasse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmModifierClasse));
            this.txtIdClasse = new System.Windows.Forms.TextBox();
            this.btnSuppression = new System.Windows.Forms.Button();
            this.btnValider = new System.Windows.Forms.Button();
            this.txtLblClasse = new System.Windows.Forms.TextBox();
            this.ModifierClasse = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRetour = new System.Windows.Forms.Button();
            this.txtPlanning = new System.Windows.Forms.TextBox();
            this.lblClasse = new System.Windows.Forms.Label();
            this.lblPlanning = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtIdClasse
            // 
            this.txtIdClasse.Location = new System.Drawing.Point(39, 61);
            this.txtIdClasse.Name = "txtIdClasse";
            this.txtIdClasse.ReadOnly = true;
            this.txtIdClasse.Size = new System.Drawing.Size(27, 20);
            this.txtIdClasse.TabIndex = 41;
            this.txtIdClasse.Visible = false;
            // 
            // btnSuppression
            // 
            this.btnSuppression.Location = new System.Drawing.Point(223, 191);
            this.btnSuppression.Name = "btnSuppression";
            this.btnSuppression.Size = new System.Drawing.Size(75, 23);
            this.btnSuppression.TabIndex = 38;
            this.btnSuppression.Text = "Supprimer";
            this.btnSuppression.UseVisualStyleBackColor = true;
            this.btnSuppression.Click += new System.EventHandler(this.btnSuppression_Click);
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(103, 191);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(75, 23);
            this.btnValider.TabIndex = 37;
            this.btnValider.Text = "Valider";
            this.btnValider.UseVisualStyleBackColor = true;
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // txtLblClasse
            // 
            this.txtLblClasse.Location = new System.Drawing.Point(120, 103);
            this.txtLblClasse.Name = "txtLblClasse";
            this.txtLblClasse.Size = new System.Drawing.Size(195, 20);
            this.txtLblClasse.TabIndex = 36;
            // 
            // ModifierClasse
            // 
            this.ModifierClasse.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ModifierClasse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ModifierClasse.Location = new System.Drawing.Point(72, 59);
            this.ModifierClasse.Name = "ModifierClasse";
            this.ModifierClasse.Size = new System.Drawing.Size(247, 29);
            this.ModifierClasse.TabIndex = 35;
            this.ModifierClasse.Text = "Modification de la classe";
            this.ModifierClasse.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::InfirmerieGUI.Properties.Resources.logo;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(166, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 44);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // btnRetour
            // 
            this.btnRetour.Location = new System.Drawing.Point(298, 12);
            this.btnRetour.Name = "btnRetour";
            this.btnRetour.Size = new System.Drawing.Size(75, 23);
            this.btnRetour.TabIndex = 24;
            this.btnRetour.Text = "Retour";
            this.btnRetour.UseVisualStyleBackColor = true;
            this.btnRetour.Click += new System.EventHandler(this.btnRetour_Click);
            // 
            // txtPlanning
            // 
            this.txtPlanning.Location = new System.Drawing.Point(120, 138);
            this.txtPlanning.Name = "txtPlanning";
            this.txtPlanning.Size = new System.Drawing.Size(195, 20);
            this.txtPlanning.TabIndex = 42;
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.Location = new System.Drawing.Point(71, 106);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(43, 13);
            this.lblClasse.TabIndex = 43;
            this.lblClasse.Text = "Libellé :";
            // 
            // lblPlanning
            // 
            this.lblPlanning.AutoSize = true;
            this.lblPlanning.Location = new System.Drawing.Point(60, 141);
            this.lblPlanning.Name = "lblPlanning";
            this.lblPlanning.Size = new System.Drawing.Size(54, 13);
            this.lblPlanning.TabIndex = 44;
            this.lblPlanning.Text = "Planning :";
            // 
            // FrmModifierClasse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 232);
            this.Controls.Add(this.lblPlanning);
            this.Controls.Add(this.lblClasse);
            this.Controls.Add(this.txtPlanning);
            this.Controls.Add(this.txtIdClasse);
            this.Controls.Add(this.btnSuppression);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.txtLblClasse);
            this.Controls.Add(this.ModifierClasse);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnRetour);
            this.Name = "FrmModifierClasse";
            this.Text = "FrmModifierClasse";
            this.Load += new System.EventHandler(this.FrmModifierClasse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdClasse;
        private System.Windows.Forms.Button btnSuppression;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.TextBox txtLblClasse;
        private System.Windows.Forms.Label ModifierClasse;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnRetour;
        private System.Windows.Forms.TextBox txtPlanning;
        private System.Windows.Forms.Label lblClasse;
        private System.Windows.Forms.Label lblPlanning;
    }
}