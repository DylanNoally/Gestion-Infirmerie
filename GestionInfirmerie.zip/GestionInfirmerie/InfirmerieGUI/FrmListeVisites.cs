﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InfirmerieBLL;
using InfirmerieBO;

namespace InfirmerieGUI
{
    public partial class FrmListeVisites : Form
    {
        private int idEleveChoisi;
        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmListeVisites(int idEleve)
        {
            InitializeComponent();

            this.idEleveChoisi = idEleve;

            List<Visite> lesVisites = new List<Visite>();
            lesVisites = GestionVisites.GetVisite(idEleveChoisi);

          //  dgv.DataSource = lesVisites;

           // dgv.Columns[0].Visible = false;
           // dgv.Columns[1].Visible = false;
           // dgv.Columns[2].Visible = false;
           // dgv.Columns[3].Visible = false;
            //dgv.Columns[4].Visible = false;
            //dgv.Columns[5].Visible = false;
           // dgv.Columns[6].Visible = false;
            //dgv.Columns[10].Visible = false;
           // dgv.Columns[11].Visible = false;
            //dgv.Columns[12].Visible = false;
            //dgv.Columns[13].Visible = false;
            //dgv.Columns[14].Visible = false;
           // dgv.Columns[15].Visible = false;

           // dgv.Columns[7].HeaderText = "Date";
            //dgv.Columns[8].HeaderText = "Motif";

            //DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            //btn.HeaderText = "Consulter";
            //btn.Name = "btnDGVModifier";
            //btn.Text = "Consulter";

            //dgv.Columns.Add(btn);

            foreach (Visite uneVisite in lesVisites)
            {
                listVisites.Items.Add(new ComboBoxItem(uneVisite.Id, uneVisite.HeureDepart + " - " + uneVisite.MotifVisite));
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmGestionVisites Visite = new FrmGestionVisites();
            Visite.Show();
            this.Hide();
        }

        private void listVisites_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind = listVisites.SelectedIndex;

            if (ind != -1)
            {
                mtxtIdVisite.Text = ((ComboBoxItem)listVisites.Items[ind]).Value.ToString();
            }
        }

        private void btnConsulter_Click(object sender, EventArgs e)
        {
            int iDvisite = Convert.ToInt32(mtxtIdVisite.Text);

            FrmModifierVisite ModifVisite = new FrmModifierVisite(iDvisite, idEleveChoisi);
            ModifVisite.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listVisites.Items.Clear();
            List<Visite> lesVisites = new List<Visite>();
            lesVisites = GestionVisites.SearchVisites(dtpSearch.Value, idEleveChoisi);

            foreach (Visite uneVisite in lesVisites)
            {
                listVisites.Items.Add(new ComboBoxItem(uneVisite.Id, uneVisite.HeureDepart + " - " + uneVisite.MotifVisite));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listVisites.Items.Clear();
            dtpSearch.Value = DateTime.Now;
            List<Visite> lesVisites = new List<Visite>();
            lesVisites = GestionVisites.GetVisite(idEleveChoisi);
            
            foreach (Visite uneVisite in lesVisites)
            {
                listVisites.Items.Add(new ComboBoxItem(uneVisite.Id, uneVisite.HeureDepart + " - " + uneVisite.MotifVisite));
            }
        }
    }
}