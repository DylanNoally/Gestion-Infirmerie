﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmAjoutVisite : Form
    {
        public FrmAjoutVisite(int idEleve)
        {
            InitializeComponent();

            // Récupération de la chaîne de connexion à la BD à l'ouverture du formulaire
            GestionUtilisateurs.SetchaineConnexion(ConfigurationManager.ConnectionStrings["Infirmerie"]);

            txtIdEleve.Text = idEleve.ToString();

            // -------------------------------------------------------------------------------------------
            // Compare ce qui a été passé à partir de la liste déroulante avec ce qu'il y a dans la BDD
            // afin d'éviter une quelconque erreur de la réactualisation de la liste déroulante
            // -------------------------------------------------------------------------------------------
            //int requeteComparaison;
            //requeteComparaison = GestionInfirmerie.VerifEleve(idEleve);

            //if (requeteComparaison != 1)
            //{
            //    // ---------------------------------------------------------------------------------------------
            //    // Si la requête ne trouve pas l'élève passé par la liste cela affiche un message d'erreur 
            //    // et renvoie sur le formulaire précédent afin de resélectionner
            //    // ---------------------------------------------------------------------------------------------
            //    MessageBox.Show("Une erreur s'est produite, réessayer de modifier l'élève !");
            //    FrmGestionVisites GestionVisite = new FrmGestionVisites();
            //    GestionVisite.Show();
            //    this.Hide();
            //}
            //else
            //{
            //    Eleve unEleve;
            //    unEleve = GestionInfirmerie.ExtractInfosEleve(id);

            //    txtIdMedicament.Text = unMedicament.Id.ToString();
            //    txtNomMedicament.Text = unMedicament.Libelle.ToString();
            //    ckbArchive.Checked = unMedicament.Archive;
            //}

        }

        private void titreGestionInfirmerie_Click(object sender, EventArgs e)
        {

        }

        private void FrmAjoutVisite_Load(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmListeVisites Visite = new FrmListeVisites();
            Visite.Show();
            this.Hide();
        }

        private void txtNomEleve_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnValider_Click(object sender, EventArgs e)
        {

        }

        //private void btnValider_Click(object sender, EventArgs e)
        //{
        //    GestionVisites uneVisite;
        //    uneVisite = new GestionVisites();

        //    bool statusRetour;
        //    bool statusHopital;
        //    bool statusLycee;
        //    bool archive;

        //    if (radioRetour.Checked == true)
        //    {
        //        statusRetour = true;
        //    }
        //    else
        //    {
        //        if (radioHopital.Checked == true)
        //        {
        //            statusHopital = true;
        //        }
        //        else
        //        {
        //            statusLycee = true;
        //        }
        //    }

        //    uneVisite.CreerVisite(txtMedicament.Text, archive);

        //    MessageBox.Show("Le médicament " + txtPrenomEleve.Text + txtNomEleve.Text + " a bien été ajouté.");

        //    FrmListeVisites listeVisite = new FrmListeVisites();
        //    listeVisite.Show();
        //    this.Hide();
        //}
    }
}
