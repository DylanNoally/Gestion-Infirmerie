﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using InfirmerieBLL; // Référence à la couche BLL
using InfirmerieBO;  // Référence à la coucher BO

namespace InfirmerieGUI
{
    public partial class FrmAjoutVisite : Form
    {
        private int idEleveChoisi;
        private int classeEleveChoisi;
        Eleve eleve;

        public class ComboBoxItem
        {
            public int Value;
            public string Text;

            public ComboBoxItem(int val, string text)
            {
                Value = val;
                Text = text;
            }

            public override string ToString()
            {
                return Text;
            }
        }

        public FrmAjoutVisite(int id, int classeEleveChoisi)
        {
            InitializeComponent();

            this.idEleveChoisi = id;
            this.classeEleveChoisi = id;

            // Récupération de la chaîne de connexion à la BD à l'ouverture du formulaire
            GestionUtilisateurs.SetchaineConnexion(ConfigurationManager.ConnectionStrings["Infirmerie"]);

            GestionInfirmerie eleveGestion = new GestionInfirmerie();

            eleve = eleveGestion.recupererDetailsEleve(idEleveChoisi);

            txtNomEleve.Text = eleve.Nom;
            txtPrenomEleve.Text = eleve.Prenom;

            GestionInfirmerie classes = new GestionInfirmerie();
            List<string> lesClasses = new List<string>();

            lesClasses = classes.recupererInfosClasses();
            listeClasses.DataSource = lesClasses;
            listeClasses.SelectedIndex = classeEleveChoisi;
            
            int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
            int dob = int.Parse(eleve.Naissance.ToString("yyyyMMdd"));
            txtAge.Text = ((now - dob) / 10000).ToString();

            GestionMedicaments medicGestion = new GestionMedicaments();
            List<Medicament> lesMedics = new List<Medicament>();
            lesMedics = medicGestion.RecuperersLesInfosMedicaments();

            foreach (Medicament unMedic in lesMedics)
            {
                clbMedicaments.Items.Add(new ComboBoxItem(unMedic.Id, unMedic.Libelle));
            }
        }

        private void titreGestionInfirmerie_Click(object sender, EventArgs e)
        {

        }

        private void FrmAjoutVisite_Load(object sender, EventArgs e)
        {
            
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRetour_Click(object sender, EventArgs e)
        {
            FrmGestionVisites Visite = new FrmGestionVisites();
            Visite.Show();
            this.Hide();
        }

        private void txtNomEleve_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            GestionVisites.CreerVisite(dtpArrivee.Value, dtpDepart.Value, txtMotif.Text, txtCommentaire.Text, txtPouls.Text, Convert.ToInt32(numUDQte.Value), cbStatut.Text, ckcParent.Checked, idEleveChoisi);

            Visite uneVisite = new Visite(dtpArrivee.Value, dtpDepart.Value, txtMotif.Text, txtCommentaire.Text, txtPouls.Text, Convert.ToInt32(numUDQte.Value), cbStatut.Text, ckcParent.Checked, idEleveChoisi);

            int idVisite = GestionVisites.GetIdVisite(uneVisite);

            List<int> lesMedics = new List<int>();

            for (int i = 0; i <= (clbMedicaments.Items.Count - 1); i++)
            {
                if (clbMedicaments.GetItemChecked(i))
                {
                    GestionVisites.LierMedicVisite(((ComboBoxItem)clbMedicaments.Items[i]).Value, idVisite);
                }
            }

            MessageBox.Show("Enregistrement de la visite effectué !", "Saisie");

            FrmGestionVisites Visite = new FrmGestionVisites();
            Visite.Show();
            this.Hide();
        }

        private void radioLycee_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void cbStatut_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
