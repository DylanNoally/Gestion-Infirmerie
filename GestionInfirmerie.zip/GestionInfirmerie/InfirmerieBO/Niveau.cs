﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfirmerieBO
{
    public class Niveau
    {
        private int id;
        private string libelle;

        public Niveau(int idNiveau, string libelleNiveau)
        {
            this.id = idNiveau;
            this.libelle = libelleNiveau;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }
    }
}
