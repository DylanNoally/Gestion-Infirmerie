﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfirmerieBO
{
    public class Visite
    {
        private int id;
        private string nom;
        private string prenom;
        private string classe;
        private int age;
        private DateTime date;
        private string heureArrive;
        private string heureDepart;
        private string motifVisite;
        private string commentaire;
        private string pouls;
        private string prescription;
        private int qte;
        private bool status;
        private bool parentsPrevenus;

        // Constructeur qui instancie un objet
        public Visite(int id, string nom, string prenom, string classe, int age, DateTime date, string heureArrive, string heureDepart, string motifVisite, string commentaire, string pouls, string prescription, int qte, bool status, bool parentsPrevenus)
        {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.classe = classe;
            this.age = age;
            this.date = date;
            this.heureArrive = heureArrive;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
            this.pouls = pouls;
            this.prescription = prescription;
            this.qte = qte;
            this.status = status;
            this.parentsPrevenus = parentsPrevenus;
        }
        
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }
        
        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }
        
        public string Classe
        {
            get { return classe; }
            set { classe = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public string HeureArrive
        {
            get { return heureArrive; }
            set { heureArrive = value; }
        }

        public string HeureDepart
        {
            get { return heureDepart; }
            set { heureDepart = value; }
        }

        public string MotifVisite
        {
            get { return motifVisite; }
            set { motifVisite = value; }
        }

        public string Commentaire
        {
            get { return commentaire; }
            set { commentaire = value; }
        }

        public string Pouls
        {
            get { return pouls; }
            set { pouls = value; }
        }

        public string Prescription
        {
            get { return prescription; }
            set { prescription = value; }
        }

        public int Qte
        {
            get { return qte; }
            set { qte = value; }
        }

        public bool Status
        {
            get { return status; }
            set { status = value; }
        }

        public bool ParentsPrevenus
        {
            get { return parentsPrevenus; }
            set { parentsPrevenus = value; }
        }
    }
}
