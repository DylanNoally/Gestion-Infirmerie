﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfirmerieBO
{
    public class Visite
    {
        private int id;
        private string nom;
        private string prenom;
        private string classe;
        private int age;
        private DateTime date;
        private DateTime heureArrive;
        private DateTime heureDepart;
        private string motifVisite;
        private string commentaire;
        private string pouls;
        private string prescription;
        private int qte;
        private string status;
        private bool parentsPrevenus;
        private int idEleve;

        public Visite(int id, DateTime heureDepart, string motifVisite, string commentaire)
        {
            this.id = id;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
        }

        // Constructeur qui instancie un objet
        public Visite(int id, string nom, string prenom, string classe, int age, DateTime date, DateTime heureArrive, DateTime heureDepart, string motifVisite, string commentaire, string pouls, string prescription, int qte, string status, bool parentsPrevenus)
        {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.classe = classe;
            this.age = age;
            this.date = date;
            this.heureArrive = heureArrive;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
            this.pouls = pouls;
            this.prescription = prescription;
            this.qte = qte;
            this.status = status;
            this.parentsPrevenus = parentsPrevenus;
        }

        public Visite(string motifVisite, string commentaire, DateTime heureArrive, DateTime heureDepart, string status, bool parentsPrevenus, string pouls, int qte)
        {
            this.heureArrive = heureArrive;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
            this.pouls = pouls;
            this.qte = qte;
            this.status = status;
            this.parentsPrevenus = parentsPrevenus;
        }

        public Visite(DateTime heureArrive, DateTime heureDepart, string motifVisite, string commentaire, string pouls , int qte, string status, bool parentsPrevenus, int idEleve)
        {
            this.heureArrive = heureArrive;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
            this.pouls = pouls;
            this.qte = qte;
            this.status = status;
            this.parentsPrevenus = parentsPrevenus;
            this.idEleve = idEleve;
        }

        public Visite(int id, DateTime heureArrive, DateTime heureDepart, string motifVisite, string commentaire, string pouls, int qte, string status, bool parentsPrevenus)
        {
            this.id = id;
            this.heureArrive = heureArrive;
            this.heureDepart = heureDepart;
            this.motifVisite = motifVisite;
            this.commentaire = commentaire;
            this.pouls = pouls;
            this.qte = qte;
            this.status = status;
            this.parentsPrevenus = parentsPrevenus;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }
        
        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }
        
        public string Classe
        {
            get { return classe; }
            set { classe = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        public DateTime HeureArrive
        {
            get { return heureArrive; }
            set { heureArrive = value; }
        }

        public DateTime HeureDepart
        {
            get { return heureDepart; }
            set { heureDepart = value; }
        }

        public string MotifVisite
        {
            get { return motifVisite; }
            set { motifVisite = value; }
        }

        public string Commentaire
        {
            get { return commentaire; }
            set { commentaire = value; }
        }

        public string Pouls
        {
            get { return pouls; }
            set { pouls = value; }
        }

        public string Prescription
        {
            get { return prescription; }
            set { prescription = value; }
        }

        public int Qte
        {
            get { return qte; }
            set { qte = value; }
        }

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public bool ParentsPrevenus
        {
            get { return parentsPrevenus; }
            set { parentsPrevenus = value; }
        }

        public int IdEleve
        {
            get { return idEleve; }
            set { idEleve = value; }
        }
    }
}
