﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfirmerieBO
{
    public class Classe
    {
        private int id;
        private string libelle;
        private string emploiDuTemps;
        private int eleveEtClasse;
        private bool possedeEDT;
        private int idNiveau;

        // Constructeur pour la modification d'une classe avec un ajout d'EDT
        public Classe(int id, string leNom, string lEmploiDuTemps, int eleve, bool possedeEDT)
        {
            this.id = id;
            this.libelle = leNom;
            this.emploiDuTemps = lEmploiDuTemps;
            this.eleveEtClasse = eleve;
            this.possedeEDT = possedeEDT;
        }

        // Constructeur pour la modification d'une classe avec un ajout d'EDT
        public Classe(string leNom, string lEmploiDuTemps, int idNiveau)
        {
            this.libelle = leNom;
            this.emploiDuTemps = lEmploiDuTemps;
            this.idNiveau = idNiveau;
        }

        // Constructeur pour la modification d'une classe sans ajout d'EDT
        public Classe(string leNom, int idNiveau)
        {
            this.libelle = leNom;
            this.idNiveau = idNiveau;
        }

        public Classe(int id, string leNom)
        {
            this.id = id;
            this.libelle = leNom;
        }

        public Classe(int id, string leNom, string lEmploiDuTemps, int idNiveau)
        {
            this.id = id;
            this.libelle = leNom;
            this.emploiDuTemps = lEmploiDuTemps;
            this.idNiveau = idNiveau;
        }

        // Constructeur qui instancie un objet
        public Classe(int id, string libelle, string emploiDuTemps, int eleveEtClasse, int idNiveau)
        {
            this.id = id;
            this.libelle = libelle;
            this.emploiDuTemps = emploiDuTemps;
            this.eleveEtClasse = eleveEtClasse;
            this.idNiveau = idNiveau;
        }

        public Classe(int id)
        {
            this.id = id;
        }

        public Classe(int id, string libelle, string emploiDuTemps)
        {
            this.id = id;
            this.libelle = libelle;
            this.emploiDuTemps = emploiDuTemps;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Libelle
        {
            get { return libelle; }
            set { libelle = value; }
        }

        public string EmploiDuTemps
        {
            get { return emploiDuTemps; }
            set { emploiDuTemps = value; }
        }

        public int EleveEtClasse
        {
            get { return eleveEtClasse; }
            set { eleveEtClasse = value; }
        }

        public int IdNiveau
        {
            get { return idNiveau; }
            set { idNiveau = value; }
        }

    }
}
