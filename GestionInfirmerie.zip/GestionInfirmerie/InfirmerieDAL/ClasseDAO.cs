﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InfirmerieBO; // Référence à la couche BO
using System.Data.SqlClient;
using System.Data;

namespace InfirmerieDAL
{
    public class ClasseDAO
    {
        private static ClasseDAO uneClasseDAO;

        // Accesseur en lecture, renvoi une instance
        public static ClasseDAO GetUneClasseDAO()
        {
            if (uneClasseDAO == null)
            {
                uneClasseDAO = new ClasseDAO();
            }
            return uneClasseDAO;
        }


        public DataTable RecupererClasses() // Requête qui permet de récupérer les classes de la BDD
        {
            // Connexion à la BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();
            DataTable data = new DataTable();

            // Création d'une liste vide d'objets Medicaments
            List<string> lesClasses = new List<string>();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT Id_classe, Libelle_classe FROM CLASSE ORDER BY Libelle_classe";

            //SqlDataReader monReader = cmd.ExecuteReader();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            // this will query your database and return the result to your datatable
            da.Fill(data);

            //while (monReader.Read())
            //{
            // Ajout de chaque libellé dans la liste Box
            //lesMedicaments.Add(monReader["Id_medicament"].ToString());
            //lesMedicaments.Add(monReader["Libelle_medicament"].ToString());
            //}
            maConnexion.Close();
            return data;
        }

        public static int GetClasse(Classe uneClasse)
        {
            int resultRequete;

            // Connexion à la BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            // Création d'une liste vide d'objets Medicaments
            List<Classe> lesClasses = new List<Classe>();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM CLASSE WHERE Id_classe = @id_classe";

            cmd.Parameters.Add(new SqlParameter("@id_classe", SqlDbType.Int, 11));

            cmd.Parameters["@id_classe"].Value = uneClasse.Id;

            SqlDataReader monReader = cmd.ExecuteReader();

            if (monReader.HasRows)
            {
                resultRequete = 1;
            }
            else
            {
                resultRequete = 0;
            }
            maConnexion.Close();
            return resultRequete;
        }

        public static Classe GetClasseInfos(int id)
        {
            string libelle = "";
            string planning = "";
            int idNiveau = 0;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM CLASSE WHERE Id_classe = "+id;

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                id = Convert.ToInt32(monReader["Id_classe"]);
                libelle = monReader["Libelle_classe"].ToString();
                planning = monReader["EmploiDuTemps"].ToString();
                idNiveau = Convert.ToInt32(monReader["Id_niveau"]);
            }

            Classe laClasse = new Classe(id, libelle, planning, idNiveau);

            maConnexion.Close();

            return laClasse;
        }

        public static int SupprimerClasse(Classe uneClasse)
        {
            int nbEnr = 0;

            int compteurEleve = 0;

            // Connexion à la BD
            SqlConnection maConnexion1 = ConnexionBD.GetConnexionBD().GetSqlConnexion();
            SqlCommand cmdVerif = new SqlCommand();
            cmdVerif.Connection = maConnexion1;
            cmdVerif.CommandText = "SELECT Id_eleve FROM ELEVE WHERE Id_classe = @id";

            cmdVerif.Parameters.Add(new SqlParameter("@id", SqlDbType.Int, 11));

            cmdVerif.Parameters["@id"].Value = uneClasse.Id;

            SqlDataReader monReader = cmdVerif.ExecuteReader();

            while (monReader.Read())
            {
                compteurEleve = compteurEleve + 1;
            }

            if (compteurEleve >= 1)
            {
                nbEnr = 2; // cela signifie qu'il y a au moins un élève dans cette classe
                maConnexion1.Close();
                return nbEnr;
            }
            maConnexion1.Close();

            // Connexion à la BD
            SqlConnection maConnexion2 = ConnexionBD.GetConnexionBD().GetSqlConnexion();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion2;

            // Requête qui supprime le médicament avec l'id passé en paramètre
            cmd.CommandText = "DELETE FROM CLASSE WHERE [Id_classe] = + @id";

            // Déclaration du paramètre @id pour protéger la requête des injections SQL
            cmd.Parameters.Add(new SqlParameter("@id", SqlDbType.Int, 11));
            cmd.Parameters["@id"].Value = uneClasse.Id;

            nbEnr = cmd.ExecuteNonQuery();

            maConnexion2.Close();

            return nbEnr;

        }


        // Cette méthode insers une nouvelle classe, avec nom et emploi du temps, passée en paramètre dans la BD
        public static int AjoutClasseAvecEDT(Classe uneClasse)
        {
            int nbEnr;

            // Connexion à la BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand("INSERT INTO CLASSE (Libelle_classe, EmploiDuTemps, PossedeEleve_classe, Id_niveau) VALUES (@leNom, @leEDT, 0, @Id_niveau)", maConnexion);

            // Attribution des valeurs aux paramètres 
            cmd.Parameters.AddWithValue("@leNom", uneClasse.Libelle);
            cmd.Parameters.AddWithValue("@leEDT", uneClasse.EmploiDuTemps);
            cmd.Parameters.AddWithValue("@Id_niveau", uneClasse.IdNiveau);

            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture de la connexion
            maConnexion.Close();

            return nbEnr;
        }

        // Cette méthode insers une nouvelle classe, avec nom mais sans l'emploi du temps, passée en paramètre dans la BD
        public static int AjoutClasseSansEDT(Classe uneClasse)
        {
            int nbEnr;

            // Connexion à la BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand("INSERT INTO classe (Libelle_classe, PossedeEleve_classe,  Id_niveau) VALUES (@leNom, 0, @Id_niveau)", maConnexion);

            // Attribution des valeurs aux paramètres 
            cmd.Parameters.AddWithValue("@leNom", uneClasse.Libelle);
            cmd.Parameters.AddWithValue("@Id_niveau", uneClasse.IdNiveau);

            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture de la connexion
            maConnexion.Close();

            return nbEnr;
        }

        public static List<Niveau> GetLesNiveaux()
        {
            List<Niveau> listeNiveaux = new List<Niveau>();
            
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM NIVEAU";

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read()) 
            {
                Niveau unNiveau = new Niveau(Convert.ToInt32(monReader["Id_niveau"]), monReader["Libelle_niveau"].ToString());
               listeNiveaux.Add(unNiveau);
            }

            maConnexion.Close();

            return listeNiveaux;
        }

        public static List<Classe> GetLesClasses()
        {
            List<Classe> listeClasses = new List<Classe>();

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM CLASSE";

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                Classe uneClasse = new Classe(Convert.ToInt32(monReader["Id_classe"]), monReader["Libelle_classe"].ToString());
                listeClasses.Add(uneClasse);
            }

            maConnexion.Close();

            return listeClasses;
        }
    }
}
