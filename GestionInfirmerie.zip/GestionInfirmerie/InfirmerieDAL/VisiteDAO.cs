﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InfirmerieBO; // Référence à la couche BO
using System.Data.SqlClient;
using System.Data;

namespace InfirmerieDAL
{
    public class VisiteDAO
    {
        //private static VisiteDAO uneVisite;

        public static double TempsVisites(DateTime Deb, DateTime Fin) {

            List<string> lesVisitesDebutS = new List<string>();
            List<string> lesVisitesFinS = new List<string>();
            List<DateTime> lesVisitesDebut = new List<DateTime>();
            List<DateTime> lesVisitesFin = new List<DateTime>();
            int i=0;
            double sommeTemps=0;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT HeureEntree_visite, HeureSortie_visite FROM VISITE WHERE CONVERT(date,Date_visite) BETWEEN '" + Deb + "' AND '" + Fin + "'";

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                lesVisitesDebutS.Add(monReader["HeureEntree_visite"].ToString());
                lesVisitesFinS.Add(monReader["HeureSortie_visite"].ToString());
            }

            foreach (string visiteDebut in lesVisitesDebutS)
            {
                DateTime visiteDebutDT = DateTime.Parse(visiteDebut);
                lesVisitesDebut.Add(visiteDebutDT);
            }

            foreach (string visiteFin in lesVisitesFinS)
            {
                DateTime visiteFinDT = DateTime.Parse(visiteFin);
                lesVisitesFin.Add(visiteFinDT);
            }

            while (i < lesVisitesDebut.Count()) 
            {
                TimeSpan span = lesVisitesFin[i].Subtract(lesVisitesDebut[i]);
                sommeTemps += span.TotalMinutes;
                i++;
            }
            maConnexion.Close();
            return sommeTemps;
        }

        public static int NbreVisites(DateTime Deb, DateTime Fin){

            int resultRequete;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT COUNT(*) FROM VISITE WHERE CONVERT(date,Date_visite) BETWEEN '"+Deb+"' AND '"+Fin+"'";
            //resultRequete = cmd.ExecuteNonQuery();
            resultRequete = (int)cmd.ExecuteScalar();
            maConnexion.Close();
            return resultRequete;
        }

        public static int NbreMedics(DateTime Deb, DateTime Fin)
        {

            int resultRequete;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT SUM(QuantiteMedicament_visite) FROM VISITE WHERE CONVERT(date,Date_visite) BETWEEN '" + Deb + "' AND '" + Fin + "'";
            resultRequete = (int)cmd.ExecuteScalar();
            maConnexion.Close();
            return resultRequete;
        }

        public static int AjoutVisite(Visite uneVisite)
        {
            int nbEnr;
            string statut = uneVisite.Status;
            int domicile = 0;
            int hopital = 0;

            if (statut == "Retour Domicile"){
                domicile = 1;
            }
            if (statut == "Hôpital"){
                hopital = 1;
            }

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "INSERT INTO VISITE (Motif_visite,Commentaire_visite,HeureEntree_visite,HeureSortie_visite,RetourDomicile_visite,Hopital_visite,ParentsPrevenus_visite,PoulsEleve_visite,QuantiteMedicament_visite,Date_visite,Id_eleve) values ('" + uneVisite.MotifVisite + "','" + uneVisite.Commentaire + "','" + uneVisite.HeureArrive + "', '" + uneVisite.HeureDepart + "', '" + domicile + "', '" + hopital + "', '" + uneVisite.ParentsPrevenus + "', '" + uneVisite.Pouls + "', '" + uneVisite.Qte + "', '" + uneVisite.HeureDepart + "', '" + uneVisite.IdEleve + "');";

            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture connexion
            maConnexion.Close();

            return nbEnr;
        }

        public static List<Visite> GetVisite(int idEleve)
        {
            List<Visite> lesVisites = new List<Visite>();

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM VISITE WHERE Id_eleve ='" + idEleve + "'";

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                //int id = Convert.ToInt32(monReader["Id_eleve"]);
                //string nom = monReader["Nom_eleve"].ToString();
                //string prenom = monReader["Prenom_eleve"].ToString();
                //int idClasse = Convert.ToInt32(monReader["Id_classe"]);

                int id = Convert.ToInt32(monReader["Id_visite"]);
                string motifVisite = monReader["Motif_visite"].ToString();
                string commentaire = monReader["Commentaire_visite"].ToString();
                DateTime date = Convert.ToDateTime(monReader["HeureEntree_visite"]);


                Visite uneVisite = new Visite(id, date, motifVisite, commentaire);
                lesVisites.Add(uneVisite);
            }
            maConnexion.Close();
            return lesVisites;
        }

        public static int LierMedVis(int idMedic, int idVisite)
        {
            int nbEnr;

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "INSERT INTO etre_lier (Id_medicament, Id_visite) values ('" + idMedic + "', '" + idVisite + "');";

            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture connexion
            maConnexion.Close();
            return nbEnr;
        }

        public static int DeleteAllMedVis(int idVisite)
        {
            int nbEnr;

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "DELETE FROM etre_lier WHERE Id_visite = " + idVisite;

            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture connexion
            maConnexion.Close();
            return nbEnr;
        }

        public static int GetIdVisite(Visite uneVisite)
        {
            int idVisite =0;
            string statut = uneVisite.Status;
            int domicile = 0;
            int hopital = 0;

            if (statut == "Retour Domicile"){
                domicile = 1;
            }
            if (statut == "Hôpital"){
                hopital = 1;
            }

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM VISITE WHERE Motif_visite = '" + uneVisite.MotifVisite + "' AND Commentaire_visite = '" + uneVisite.Commentaire + "' AND HeureEntree_visite = '" + uneVisite.HeureArrive + "' AND HeureSortie_visite = '" + uneVisite.HeureDepart + "' AND RetourDomicile_visite = '" + domicile + "' AND Hopital_visite = '" + hopital + "' AND ParentsPrevenus_visite = '" + uneVisite.ParentsPrevenus + "' AND PoulsEleve_visite = '" + uneVisite.Pouls + "' AND QuantiteMedicament_visite = '" + uneVisite.Qte + "'";

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                idVisite = Convert.ToInt32(monReader["Id_visite"]);
            }

            maConnexion.Close();

            return idVisite;
        }

        public static Visite GetLaVisite(int idVisite)
        {
            Visite uneVisite = null;

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM VISITE WHERE Id_visite = " + idVisite ;

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                string statut = "";
                string motif = (monReader["Motif_visite"]).ToString();
                string commentaire = (monReader["Commentaire_visite"]).ToString();
                DateTime arrivee = Convert.ToDateTime(monReader["HeureEntree_visite"]);
                DateTime sortie = Convert.ToDateTime(monReader["HeureSortie_visite"]);
                bool domicile = Convert.ToBoolean(monReader["RetourDomicile_visite"]);
                bool hopital = Convert.ToBoolean(monReader["Hopital_visite"]);
                bool parent = Convert.ToBoolean(monReader["ParentsPrevenus_visite"]);
                string pouls = (monReader["PoulsEleve_visite"]).ToString();
                int qte = Convert.ToInt32(monReader["QuantiteMedicament_visite"]);

                if (domicile == true) 
                {
                    statut = "1";
                }
                if (hopital == true)
                {
                    statut = "2";
                }

                uneVisite = new Visite(motif, commentaire, arrivee, sortie, statut, parent, pouls, qte);
            }

            maConnexion.Close();

            return uneVisite;
        }

        public static int DeleteVisite(int idVisite)
        {
            int nbr = 0;

            // Connexion BD
            SqlConnection maConnexion1 = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd1 = new SqlCommand();
            cmd1.Connection = maConnexion1;
            cmd1.CommandText = "DELETE FROM etre_lier WHERE Id_visite = " + idVisite;
            nbr = cmd1.ExecuteNonQuery();

            maConnexion1.Close();


            nbr = 0;
            // Connexion BD
            SqlConnection maConnexion2 = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd2 = new SqlCommand();
            cmd2.Connection = maConnexion2;
            cmd2.CommandText = "DELETE FROM VISITE WHERE Id_visite = " + idVisite;
            nbr = cmd2.ExecuteNonQuery();

            maConnexion2.Close();

            return nbr;
        }

        public static int UpdateVisite(Visite uneVisite)
        {
            int nbEnr; 
            string statut = uneVisite.Status;
            int domicile = 0;
            int hopital = 0;

            if (statut == "à son domicile")
            {
                domicile = 1;
            }
            if (statut == "à l'hôpital")
            {
                hopital = 1;
            }

            // Connexion à la BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "UPDATE VISITE SET Motif_visite ='" + uneVisite.MotifVisite + "',Commentaire_visite = '" + uneVisite.Commentaire + "',HeureEntree_visite = '" + uneVisite.HeureArrive + "',HeureSortie_visite = '" + uneVisite.HeureDepart + "',RetourDomicile_visite = '" + domicile + "',Hopital_visite = '" + hopital + "',ParentsPrevenus_visite = '" + uneVisite.ParentsPrevenus + "',PoulsEleve_visite = '" + uneVisite.Pouls + "',QuantiteMedicament_visite = '" + uneVisite.Qte + "' WHERE Id_visite ="+ uneVisite.Id;
            nbEnr = cmd.ExecuteNonQuery();

            // Fermeture de la connexion maConnexion.Close(); 
            maConnexion.Close();

            return nbEnr;
        }

        public static List<int> listeIdMedicamentsLies(int idVisite)
        {
            List<int> listeMedicaments = new List<int>();

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM etre_lier, MEDICAMENT WHERE etre_lier.Id_medicament = MEDICAMENT.Id_medicament AND etre_lier.Id_visite = "+ idVisite;

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                int idMedicament = Convert.ToInt32(monReader["Id_medicament"]);
                listeMedicaments.Add(idMedicament);
            }

            maConnexion.Close();

            return listeMedicaments;
        }

        public static List<Visite> SearchVisites(DateTime date, int idEleve)
        {
            List<Visite> listeVisite = new List<Visite>();

            // Connexion BD
            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = maConnexion;
            cmd.CommandText = "SELECT * FROM VISITE WHERE YEAR(HeureEntree_visite) = "+date.Year+" AND MONTH(HeureEntree_visite) = "+date.Month+" AND Id_eleve = "+idEleve;

            SqlDataReader monReader = cmd.ExecuteReader();

            while (monReader.Read())
            {
                //int id = Convert.ToInt32(monReader["Id_eleve"]);
                //string nom = monReader["Nom_eleve"].ToString();
                //string prenom = monReader["Prenom_eleve"].ToString();
                //int idClasse = Convert.ToInt32(monReader["Id_classe"]);

                int id = Convert.ToInt32(monReader["Id_visite"]);
                string motifVisite = monReader["Motif_visite"].ToString();
                string commentaire = monReader["Commentaire_visite"].ToString();
                DateTime dateVisite = Convert.ToDateTime(monReader["HeureEntree_visite"]);

                Visite uneVisite = new Visite(id, dateVisite, motifVisite, commentaire);
                listeVisite.Add(uneVisite);
            }
            maConnexion.Close();

            return listeVisite;
        }

        // Ici se trouve la méthode pour compter le nombre total de visites par période merci //
        public static int NbTotalVisite(string dateDebut, string dateFin)
        {
            int nbVisite = 0;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(Id_visite) as nbVisite FROM VISITE WHERE Date_visite BETWEEN @dateDebut AND @dateFin", maConnexion);

            cmd.Parameters.AddWithValue("@dateDebut", dateDebut);
            cmd.Parameters.AddWithValue("@dateFin", dateFin);

            nbVisite = (int)cmd.ExecuteScalar();
            maConnexion.Close();
            return nbVisite;
        }
    }
}
