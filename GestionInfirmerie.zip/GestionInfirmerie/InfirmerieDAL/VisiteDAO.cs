﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InfirmerieBO; // Référence à la couche BO
using System.Data.SqlClient;
using System.Data;

namespace InfirmerieDAL
{
    public class VisiteDAO
    {
        // Ici se trouve la méthode pour compter le nombre total de visites par période merci //
        public static int NbTotalVisite(string dateDebut, string dateFin)
        {
            int nbVisite = 0;

            SqlConnection maConnexion = ConnexionBD.GetConnexionBD().GetSqlConnexion();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(Id_visite) as nbVisite FROM VISITE WHERE Date_visite BETWEEN @dateDebut AND @dateFin", maConnexion);

            cmd.Parameters.AddWithValue("@dateDebut", dateDebut);
            cmd.Parameters.AddWithValue("@dateFin", dateFin);

            nbVisite = (int)cmd.ExecuteScalar();
            maConnexion.Close();
            return nbVisite;

        }
    }
}
